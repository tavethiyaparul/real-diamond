"use strict";

var _this = module.exports = {
        isUserAgent: function (data, constant, socket) {
		//	console.log("HostCall isUserAgent "+JSON.stringify(data));
		//if(data.userId=="5fab752c1762dc1f85d2a040")	
		//	console.log("UserCall isUserAgent "+JSON.stringify(data));
        //if(data.userId=="116478961723906020247")	
		//	console.log("HostCall isUserAgent "+JSON.stringify(data));
           
		   constant.MongoDb.user_masters.findOne(
                {uid: data.userId}
                , function (err, res) {
				
					//if(data.userId=="100503652495048460138")	
					//	console.log("UserCall FIND "+JSON.stringify(res));
                    // if(data.userId=="108374367725590581752")	
					//	console.log("HostCall FIND "+JSON.stringify(res));
         
					if(!err && res != null)
                    socket.emit('VideoClient', {
                        eventName: data.eventName,
                        isUserAgent:   res._id,//MASTER iD
                        private_call_rate:   res.private_call_rate,
                        one_to_one_call_rate:   res.one_to_one_call_rate,
                    });
                })
        }
        ,
        CoinDeduct:
			
            function (data, constant, socket) {
				
				//console.log("UserCall CoinDeduct "+JSON.stringify(data));
				//if(data.userId=="116478961723906020247")	
				//	console.log("UserCall CoinDeduct "+JSON.stringify(data));
				// if(data.userId=="108374367725590581752")	
				//	console.log("HostCall CoinDeduct "+JSON.stringify(data));
				//console.log("HostCall CoinDeduct "+JSON.stringify(data));
                constant.MongoDb.user.findOne(
                    {_id: data.userId}
                    , function (err, res) {
                        if (!err && res != null) {
                            if (data.coinType === 1) {
                                /*Free coin*/
                                let NeedDeductCoin = res.payload.FreeCoin;
                                if (NeedDeductCoin > data.deductCoin) {
                                    NeedDeductCoin = data.deductCoin;
                                }
                                constant.MongoDb.user.updateOne(
                                    {_id: data.userId},
                                    {$inc: {"payload.FreeCoin": -NeedDeductCoin}}, {upsert: true}
                                    , function (err, result) {
                                        socket.emit('VideoClient', {
                                            eventName: data.eventName,
                                            CoinType: data.coinType,
                                            RemainCoin: (res.payload.FreeCoin - NeedDeductCoin > 0) ? res.payload.FreeCoin - NeedDeductCoin : 0
                                        });
                                    })

                            } else if (data.coinType === 2) {
                                /*main coin*/


                                let NeedDeductCoin = res.payload.Coin;
								
                                if (NeedDeductCoin > data.deductCoin) {
                                    NeedDeductCoin = data.deductCoin;
                                }
								
								// if(data.userId=="100503652495048460138")	
								//	console.log("UserCall NeedDeductCoin "+JSON.stringify(NeedDeductCoin)+" HAVE COIN "+JSON.stringify(res.payload.Coin));
								// if(data.userId=="108374367725590581752")	
								//	console.log("HostCall NeedDeductCoin "+JSON.stringify(NeedDeductCoin)+" HAVE COIN "+JSON.stringify(res.payload.Coin));
								//
								
                                constant.MongoDb.user.updateOne(
                                    {_id: data.userId},
                                    {$inc: {"payload.Coin": -NeedDeductCoin}}, {upsert: true}
                                    , function (err, result) {
                                        socket.emit('VideoClient', {
                                            eventName: data.eventName,
                                            CoinType: data.coinType,
                                            RemainCoin: (res.payload.Coin - NeedDeductCoin > 0) ? res.payload.Coin - NeedDeductCoin : 0
                                        });
                                    })


                            }
                        }

                    });
            },
		
		HostCoinCheck:// Check Normal User Check Coin Status
			
            function (data, constant, socket) {
				
				//console.log("UserCall CoinDeduct "+JSON.stringify(data));
				//console.log("HostCoinCheck CoinDeduct Call");
                constant.MongoDb.user.findOne(
                    {_id: data.userId}
                    , function (err, res) {
                        if (!err && res != null) {
                          
						  
							if (data.hostUserId !== undefined && data.hostUserId != null)
							{
									constant.MongoDb.user_masters.findOne(
										{uid: data.hostUserId}
										, function (err, res1) {
										
											//if(data.userId=="100503652495048460138")	
											//	console.log("UserCall FIND "+JSON.stringify(res));
											// if(data.userId=="108374367725590581752")	
											//	console.log("HostCall FIND "+JSON.stringify(res));
											//console.log("HostCoinCheck Rate Returtn "+JSON.stringify(res.payload.Coin));
											if(!err && res1 != null)
												socket.emit('VideoClient', {
													eventName: data.eventName,
													RemainCoin: res.payload.Coin,
													private_call_rate:   res1.private_call_rate,
													one_to_one_call_rate:   res1.one_to_one_call_rate,
												});
										});
							}
							else{
								//console.log("HostCoinCheck CoinDeduct "+JSON.stringify(res.payload.Coin));
								socket.emit('VideoClient', {
											eventName: data.eventName,
											RemainCoin: res.payload.Coin
										});
							}
								

                            
                        }

                    });
            }

    }
;
