"use strict";

var _this = module.exports = {
    UserStatus: function (data, constant, socket) {

        data['SocketId'] = socket.id;
        delete data["eventName"];
        constant.MongoDb.liveuser.updateOne(
            {_id: data.userId},
            {$set: {payload: data}}, {upsert: true}
            , function (err, res) {
                if (!err) {

                    constant.MongoDb.friend.aggregate([
                        {$match: {_id: data.userId}}
                        ,
                        {
                            $lookup:
                                {
                                    from: 'liveuser',
                                    localField: 'payload.accepted',
                                    foreignField: '_id',
                                    as: 'UserObj'
                                }
                        },
                        {$unwind: {path: '$UserObj', preserveNullAndEmptyArrays: true}},
                        {$project: {UserObj: 1}},
                        {"$replaceRoot": {"newRoot": {"$mergeObjects": ["$UserObj.payload"]}}}
                    ]).toArray(function (err, res) {
                        if (!err && res != null && res.length > 0) {
                            for (let key in res) {
                                let value = res[key]; // get the value by key
                                constant.io.to(value.SocketId).emit('VideoClient', {
                                    eventName: "IsOnline",
                                    OtherUserId: data.userId,
                                    status: 1
                                });
                            }
                        }

                    });


                }

            });
        // }
    }, IsOnline: function (data, constant, socket) {
        constant.MongoDb.liveuser.findOne(
            {_id: data.userId}
            , function (err, res) {

                socket.emit('VideoClient', {
                    eventName: data.eventName,
                    OtherUserId: data.userId,
                    status: !err && res != null ? 1 : 0
                });


            });

    }

};
