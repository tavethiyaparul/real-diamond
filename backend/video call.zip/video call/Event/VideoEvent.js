"use strict"

var _this = (module.exports = {
    CurrentTimeStamp: function (data, constant, socket) {
        const dataCurrent = {
            eventName: data.eventName,
            currentTime: new Date(),
        }
        socket.emit("VideoClient", JSON.stringify(dataCurrent))
    },
    FakeVideo: function (data, constant, socket) {
        constant.MongoDb.fake_video.aggregate([{ $sample: { size: 1 } }]).toArray(function (err, res) {
            if (!err && res != null && res.length > 0) {
                // console.log("Status", res.payload.SocketId)
                data.video = res[0].name
                socket.emit("VideoClient", data)
            }
        })
    },
    HostIsOnline: function (data, constant, socket) {
        constant.MongoDb.history
            .aggregate([
                { $match: { _id: data.userId } },
                {
                    $lookup: {
                        from: "user",
                        localField: "_id",
                        foreignField: "_id",
                        as: "user",
                    },
                },
                { $unwind: "$user" },
                {
                    $lookup: {
                        from: "user",
                        localField: "payload.caller.id",
                        foreignField: "_id",
                        as: "UserHistory",
                    },
                },
                {
                    $lookup: {
                        from: "user_masters",
                        localField: "_id",
                        foreignField: "uid",
                        as: "UserMaster",
                    },
                },
                {
                    $addFields: {
                        "user.payload.tokenarray": "$UserHistory.payload.token",
                        "user.payload.package_name": "$UserHistory.payload.package_name",
                        "user.payload.first_name": "$UserMaster.first_name",
                        "user.payload.last_name": "$UserMaster.last_name",
                    },
                },
                { $replaceRoot: { newRoot: "$user.payload" } },
            ])
            .toArray(function (err, historyresult) {
                if (!err && historyresult != null && historyresult.length > 0) {
                    var payload = {
                        eventName: "HostisOnline",
                        msg: "💞 " + historyresult[0].first_name + " " + historyresult[0].last_name + " is Waiting for your Call 📞",
                        name: "💋 " + historyresult[0].first_name + " " + historyresult[0].last_name + " is Online 🟢",
                    }
                    let message = new constant.gcm.Message({
                        data: { payload },
                    })
                    //console.log("HostOnline "+JSON.stringify(historyresult));

                    // if(historyresult[0].userId!="108374367725590581752")// Ristrict Ashish Host On Testing
                    // if (data.hasOwnProperty('package_name'))
                    // {
                    //	console.log("WIth PACKAGENAME_-------- "+JSON.stringify(data));
                    //	constant.MongoDb.package.findOne(
                    //		{package_name: historyresult[0].package_name}
                    //		, function (err, result) {
                    //			if (result != null) {
                    //			    console.log("result_gcm_ARRAY-->",result)
                    //			    console.log("result_gcm_key-->",result.gcm_key)
                    //
                    //				constant.gcm.Sender(result.gcm_key).sendNoRetry(message,
                    //					{registrationTokens: historyresult[0].tokenarray}, function (err, res) {
                    //					});
                    //			} else {
                    //
                    //				constant.sender.sendNoRetry(message,
                    //					{registrationTokens: historyresult[0].tokenarray}, function (err, response) {
                    //
                    //					});
                    //			}
                    //		});
                    // }
                    //else
                    //{
                    //	console.log("WITHOUT PACKAGENAME_-------- ");
                    //	constant.sender.sendNoRetry(message,
                    //		{registrationTokens: historyresult[0].tokenarray}, function (err, response) {
                    //
                    //		});
                    //}

                    if (historyresult[0].userId != "108374367725590581752")
                        if (data.hasOwnProperty("package_name")) {
                            // Ristrict Ashish Host On Testing
                            //console.log("WIth PACKAGENAME_-------- "+JSON.stringify(data));
                            constant.MongoDb.package.find().toArray(function (err, result) {
                                if (result != null) {
                                    //console.log("result_gcm_ARRAY-->",result)
                                    //console.log("result_gcm_key-->",result.gcm_key)

                                    result.forEach(function (k) {
                                        //console.log("result_gcm_key-->",k.package_name);
                                        constant.gcm.Sender(k.gcm_key).sendNoRetry(message, { registrationTokens: historyresult[0].tokenarray }, function (err, res) {})
                                    })
                                } else {
                                    constant.sender.sendNoRetry(message, { registrationTokens: historyresult[0].tokenarray }, function (err, response) {})
                                }
                            })
                        } else {
                            //console.log("WITHOUT PACKAGENAME_-------- ");
                            constant.sender.sendNoRetry(message, { registrationTokens: historyresult[0].tokenarray }, function (err, response) {})
                        }
                }
            })
    },
    Status: function (data, constant, socket) {
        constant.MongoDb.liveuser.findOne({ _id: data.userId }, function (err, res) {
            if (!err && res != null) {
                // console.log("Status", res.payload.SocketId)
                constant.io.to(res.payload.SocketId).emit("VideoClient", data)
            }
        })
    },
    UpdateSocket: function (data, constant, socket) {
        constant.MongoDb.liveuser.updateOne({ _id: data.userId }, { $set: { "payload.SocketId": socket.id } }, function (err, res) {})
    },
    RandomCall: function (data, constant, socket, callback) {
        // console.log(data);

        //console.log("-----RandomCall-----------");

        //
        // let IsGender= data.hasOwnProperty('Gender')? "payload.Gender":data.Gender  :"";
        //todo remove make Query=null & uncomment if else.
        let Query = { _id: { $ne: data.userId }, "payload.status": 3 }
        // if (data.Sel_gen < 0) {
        //     Query = {
        //         _id: {$ne: data.userId},
        //         "payload.status": 3,
        //         $or: [{"payload.Sel_gen": {$eq: -1}}, {"payload.Sel_gen": data.userObj.Gender}]
        //     };
        // } else {
        //     Query = {
        //         _id: {$ne: data.userId},
        //         "payload.status": 3,
        //         "payload.userObj.Gender": {$eq: data.Sel_gen},
        //         $or: [{"payload.Sel_gen": {$eq: -1}}, {"payload.Sel_gen": data.userObj.Gender}]
        //     };
        // }
        /*if(data.userId=="113718473168822942055")
        	{

        		//console.log("-----userId-----------"+JSON.stringify(data));
        		 delete data["eventName"];
	                        data['SocketId'] = socket.id;
	                        constant.MongoDb.liveuser.updateOne(
	                            {_id: data.userId},
	                            {$set: {payload: data}}, {upsert: true}
	                            , function (err, res) {
	                                if (!err && callback != null) {
	                                   // callback();

	                                }

	                            });
        	}
        	else*/ if (data.hasOwnProperty("master_id")) {
            //console.log("-----master_id-----------"+JSON.stringify(data));

            let Query = { _id: { $ne: data.userId }, "payload.status": 3, "payload.userObj.package_name": "com.videocall.randomcallapps" }
            //let Query = {_id: "113718473168822942055",  "payload.userObj.package_name": "com.videocall.randomcallapps"};//"payload.status": 3,

            constant.MongoDb.liveuser.findOne(Query, function (err, res) {
                //console.log("-----Find-----------"+JSON.stringify(res));
                if (!err && res != null) {
                    let result = res
                    data["SocketId"] = socket.id
                    data.status = 1
                    delete data["eventName"]
                    //  console.log(result);

                    var batch = constant.MongoDb.liveuser.initializeUnorderedBulkOp({ useLegacyOps: true })
                    batch.find({ _id: result._id }).updateOne({ $set: { "payload.status": 1 } })

                    batch
                        .find({ _id: data.userId })
                        .upsert()
                        .updateOne({ $set: { payload: data } })

                    batch.execute(function (err, res) {
                        if (!err) {
                            result["userId"] = data.userId
                            _this.StatusFriend(data, constant, result, function (StatusResult) {
                                data["s_socketId"] = socket.id
                                data["eventName"] = "RandomCall"
                                data["status"] = StatusResult
                                constant.io.to(result.payload.SocketId).emit("VideoClient", data)
                                if (callback != null) {
                                    callback()
                                }
                            })
                        }
                    })
                } else {
                    delete data["eventName"]
                    data["SocketId"] = socket.id
                    constant.MongoDb.liveuser.updateOne({ _id: data.userId }, { $set: { payload: data } }, { upsert: true }, function (err, res) {
                        if (!err && callback != null) {
                            callback()
                        }
                    })
                }
            })
        } else
            constant.MongoDb.liveuser.findOne(Query, function (err, res) {
                if (!err && res != null) {
                    let result = res
                    data["SocketId"] = socket.id
                    data.status = 1
                    delete data["eventName"]
                    //  console.log(result);

                    var batch = constant.MongoDb.liveuser.initializeUnorderedBulkOp({ useLegacyOps: true })
                    batch.find({ _id: result._id }).updateOne({ $set: { "payload.status": 1 } })

                    batch
                        .find({ _id: data.userId })
                        .upsert()
                        .updateOne({ $set: { payload: data } })

                    batch.execute(function (err, res) {
                        if (!err) {
                            result["userId"] = data.userId
                            _this.StatusFriend(data, constant, result, function (StatusResult) {
                                data["s_socketId"] = socket.id
                                data["eventName"] = "RandomCall"
                                data["status"] = StatusResult
                                constant.io.to(result.payload.SocketId).emit("VideoClient", data)
                                if (callback != null) {
                                    callback()
                                }
                            })
                        }
                    })
                } else {
                    delete data["eventName"]
                    data["SocketId"] = socket.id
                    constant.MongoDb.liveuser.updateOne({ _id: data.userId }, { $set: { payload: data } }, { upsert: true }, function (err, res) {
                        if (!err && callback != null) {
                            callback()
                        }
                    })
                }
            })
    },

    RandomCallAudio: function (data, constant, socket, callback) {
        // console.log(data);

        //console.log("-----RandomCallAdio Success-----------");

        let Query = { _id: { $ne: data.userId }, "payload.status": 3 }

        constant.MongoDb.liveuser_audio.findOne(Query, function (err, res) {
            if (!err && res != null) {
                let result = res
                data["SocketId"] = socket.id
                data.status = 1
                delete data["eventName"]
                //  console.log(result);

                var batch = constant.MongoDb.liveuser_audio.initializeUnorderedBulkOp({ useLegacyOps: true })
                batch.find({ _id: result._id }).updateOne({ $set: { "payload.status": 1 } })

                batch
                    .find({ _id: data.userId })
                    .upsert()
                    .updateOne({ $set: { payload: data } })

                batch.execute(function (err, res) {
                    if (!err) {
                        result["userId"] = data.userId
                        _this.StatusFriend(data, constant, result, function (StatusResult) {
                            data["s_socketId"] = socket.id
                            data["eventName"] = "RandomCallAudio"
                            data["status"] = StatusResult
                            constant.io.to(result.payload.SocketId).emit("VideoClient", data)
                            if (callback != null) {
                                callback()
                            }
                        })
                    }
                })
            } else {
                delete data["eventName"]
                data["SocketId"] = socket.id
                constant.MongoDb.liveuser_audio.updateOne({ _id: data.userId }, { $set: { payload: data } }, { upsert: true }, function (err, res) {
                    if (!err && callback != null) {
                        callback()
                    }
                })
            }
        })
    },

    ByPush: function (data, constant, socket) {
        var temp_data = {}
        temp_data["userId"] = data.r_userId
        temp_data["status"] = 1
        temp_data["push"] = 1
        var batch = constant.MongoDb.liveuser.initializeUnorderedBulkOp({ useLegacyOps: true })
        batch
            .find({ _id: data.r_userId })
            .upsert()
            .updateOne({ $set: { payload: temp_data } })
        batch.execute(function (err, result) {})
    },
    CreateCall: async function (data, constant, socket) {
        constant.MongoDb.liveuser.find({ _id: data.r_userId }).toArray(function (err, res) {
            //console.log("liveuser data  "+JSON.stringify(data));
            if (!err && res != null && res.length > 0) {
                let result = res[0]

                if (result.payload.status === 1) {
                    //when receiver already in call
                    data["eventName"] = "FinishSingleCall"
                    socket.emit("VideoClient", data)
                } else {
                    //console.log("ELSE");
                    constant.MongoDb.user.find({ _id: { $in: [data.s_userId, data.r_userId] } }).toArray(function (err, res1) {
                        if (!err && res1 != null && res1.length > 0) {
                            var su

                            if (res1[0] != null && res1[1] != null && res1[0].payload.master_id == null && res1[1].payload.master_id == null) {
                                su = data.s_userId == res1[0]._id ? res1[0] : res1[1]
                                //console.log("TRUEEEEEEEE"+JSON.stringify(su));
                            } else {
                                // Host call
                                su = data.s_userId == res1[0]._id ? (res1[0].payload.master_id == null ? res1[0] : res1[1]) : res1[1].payload.master_id == null ? res1[1] : res1[0]
                                //console.log("FALSEEEEEEEE"+JSON.stringify(su)+" res[0] " +JSON.stringify(res[0])+" res[1] " +JSON.stringify(res[1]) );
                            }

                            //console.log("User Coin "+ JSON.stringify(su));
                            if (su.payload.Coin != null && su.payload.package_name != null && su.payload.app_version != null && su.payload.Coin > 0 && su.payload.package_name == "com.videocall.randomcallapps") {
                                //when receiver using app
                                var userId = [data.s_userId, result._id]
                                constant.MongoDb.liveuser.updateMany(
                                    { _id: { $in: userId } },
                                    { $set: { "payload.status": 1 } }, //, "payload.SocketId": socket.id
                                    function (err, res) {
                                        if (!err) {
                                            //is receiver is online but not in call then lock sender and receiver both

                                            constant.MongoDb.ice_server.findOne({}, function (err, res) {
                                                if (!err && res != null) {
                                                    data["s_socketId"] = socket.id
                                                    data["eventName"] = "HostCallPing"
                                                    data["ice_server"] = JSON.stringify(res)
                                                    constant.io.to(result.payload.SocketId).emit("VideoClient", data)
                                                }
                                            })
                                        }
                                    }
                                )
                            } else {
                                data["eventName"] = "FinishSingleCall"
                                socket.emit("VideoClient", data)
                            }
                        } else {
                            data["eventName"] = "FinishSingleCall"
                            socket.emit("VideoClient", data)
                        }
                    })
                }
            } else {
                //push notification  { "$in" : [ data.r_userId,data.s_userId]}
                constant.MongoDb.user.find({ _id: { $in: [data.s_userId, data.r_userId] } }).toArray(function (err, res) {
                    if (!err && res != null && res.length > 0) {
                        //Testing
                        /*if(res[0]!=null&&res[1]!=null&&(res[0]._id=="108645488374799489336"||res[0]._id=="108645488374799489336"))
								{
									console.log("s_userId ---> "+JSON.stringify((data.s_userId==res[0]._id)?res[0]:res[1]));
									console.log("r_userId ---> "+JSON.stringify((data.r_userId==res[0]._id)?res[0]:res[1]));
								}else
									console.log("Other User");
								*/

                        var su

                        /*if(res[0]!=null&&res[1]!=null&&(res[0].payload.master_id==null&&res[1].payload.master_id==null))
								{
									
									su=(data.s_userId==res[0]._id)?res[0]:res[1];
									//console.log("TRUEEEEEEEE"+JSON.stringify(su));
								}
								else
								{
									
										su=(data.s_userId==res[0]._id)?((res[0].payload.master_id==null)?res[0]:res[1]):((res[1].payload.master_id==null)?res[1]:res[0]);
										//console.log("FALSEEEEEEEE"+JSON.stringify(su)+" res[0] " +JSON.stringify(res[0])+" res[1] " +JSON.stringify(res[1]) );
								}*/
                        //
                        su = data.s_userId == res[0]._id ? res[0] : res[1]

                        //if(res[0]!=null&&res[1]!=null&&(res[0]._id=="113739504780297075749"||res[1]._id=="113739504780297075749"))
                        //{
                        //	console.log("Manish Agrahari : s_userId ---> "+JSON.stringify(su) + " res[0] " + JSON.stringify(res[0])+" res[1] " + JSON.stringify(res[1]));
                        //
                        //}else
                        //	console.log("Other User");
                        //
                        //su=(su==undefined)?res[0]==undefined?res[1]:res[0]:su;

                        //if(su.payload.hasOwnProperty("master_id") && su.payload.master_id=="5fab752c1762dc1f85d2a040" && su.payload.master_id=="116478961723906020247")
                        //	console.log("MEgha shing "+JSON.stringify(su));
                        //
                        //if((res[0]!=null&&res[1]!=null&&(res[0]._id=="5fab752c1762dc1f85d2a040"||res[1]._id=="5fab752c1762dc1f85d2a040"))|| (res[0]!=null&&res[1]!=null&&(res[0]._id=="116478961723906020247"||res[1]._id=="116478961723906020247")))
                        //{
                        //	console.log("s_userId ---> "+JSON.stringify(su) + " res[0] " + JSON.stringify(res[0])+" res[1] " + JSON.stringify(res[1]));
                        //
                        //}else
                        //	console.log("Other User");

                        //console.log("Payload Check "+JSON.stringify(su));
                        //su._id=="108374367725590581752"||
                        //(!su.payload.hasOwnProperty("master_id")) &&
                        if (su != null && su.payload != null && su.payload.Coin != null && su.payload.package_name != null && su.payload.app_version != null && su.payload.package_name == "com.videocall.randomcallapps" && !su.payload.hasOwnProperty("master_id") && su.payload.Coin > 0) {
                            //if(su.payload.hasOwnProperty("master_id") && su.payload.master_id=="60cada7ddc21013c7fa1b2c4")
                            //	console.log("Accept Call "+JSON.stringify(su));
                            //
                            //console.log("data  "+JSON.stringify(data));
                            var temp_data = {}
                            temp_data["userId"] = data.r_userId
                            temp_data["status"] = 1
                            temp_data["push"] = 1

                            var batch = constant.MongoDb.liveuser.initializeUnorderedBulkOp({ useLegacyOps: true })
                            batch.find({ _id: data.s_userId }).updateOne({ $set: { "payload.status": 1 } })

                            batch
                                .find({ _id: data.r_userId })
                                .upsert()
                                .updateOne({ $set: { payload: temp_data } })
                            batch.execute(function (err, result) {
                                if (!err) {
                                    constant.MongoDb.ice_server.findOne({}, function (err, iceres) {
                                        if (!err && iceres != null) {
                                            data["s_socketId"] = socket.id
                                            data["eventName"] = "LivevideoPush"
                                            data["date"] = constant.CurrentTimeStamp()
                                            data["ice_server"] = JSON.stringify(iceres)

                                            //data['host_name'] = res[0].payload.hasOwnProperty('host_name')
                                            if (res[0] != null && res[0].payload.hasOwnProperty("host_name")) {
                                                data["host_name"] = res[0].payload.host_name
                                            } else if (res[1] != null && res[1].payload.hasOwnProperty("host_name")) {
                                                data["host_name"] = res[1].payload.host_name
                                            }

                                            let message = new constant.gcm.Message({
                                                data: { data },
                                            })
                                            //if(res[0]!=null&&res[1]!=null&&(res[0]._id=="108374367725590581752"||res[0]._id=="108374367725590581752"))
                                            //	console.log("data  "+JSON.stringify(data));

                                            if (data.hasOwnProperty("package_name")) {
                                                //console.log("With package_name");
                                                if (res[0] != null && res[1] != null) {
                                                    constant.MongoDb.package.findOne({ package_name: data.r_userId == res[0]._id ? res[0].payload.package_name : res[1].payload.package_name }, function (err, result) {
                                                        if (result != null) {
                                                            //console.log("gcm_key "+result.gcm_key);
                                                            constant.gcm.Sender(result.gcm_key).sendNoRetry(message, { registrationTokens: [data.r_userId == res[0]._id ? res[0].payload.token : res[1].payload.token] }, function (err, res) {
                                                                //response.end(ConstantMethod.sucess((data.r_userId==res[0]._id)?res[0]:res[1]));
                                                                //response.end(ConstantMethod.sucess(res));
                                                                //console.log("Success "+res);
                                                            })

                                                            //constant.sender.sendNoRetry(message,
                                                            //	{registrationTokens: [(data.r_userId==res[0]._id)?res[0].payload.token:res[1].payload.token]}, function (err, response) {
                                                            //
                                                            //	});
                                                        } else {
                                                            //console.log("else gcm_key "+result.gcm_key);
                                                            constant.sender.sendNoRetry(message, { registrationTokens: [data.r_userId == res[0]._id ? res[0].payload.token : res[1].payload.token] }, function (err, response) {})
                                                        }
                                                    })
                                                } else if (res[0] != null) {
                                                    constant.MongoDb.package.findOne({ package_name: res[0].payload.package_name }, function (err, result) {
                                                        if (result != null) {
                                                            //console.log("gcm_key "+result.gcm_key);
                                                            constant.gcm.Sender(result.gcm_key).sendNoRetry(message, { registrationTokens: [res[0].payload.token] }, function (err, res) {
                                                                //response.end(ConstantMethod.sucess((data.r_userId==res[0]._id)?res[0]:res[1]));
                                                                //response.end(ConstantMethod.sucess(res));
                                                                //console.log("Success "+res);
                                                            })

                                                            //constant.sender.sendNoRetry(message,
                                                            //	{registrationTokens: [(data.r_userId==res[0]._id)?res[0].payload.token:res[1].payload.token]}, function (err, response) {
                                                            //
                                                            //	});
                                                        } else {
                                                            //console.log("else gcm_key "+result.gcm_key);
                                                            constant.sender.sendNoRetry(message, { registrationTokens: [res[0].payload.token] }, function (err, response) {})
                                                        }
                                                    })
                                                } else if (res[1] != null) {
                                                    constant.MongoDb.package.findOne({ package_name: res[1].payload.package_name }, function (err, result) {
                                                        if (result != null) {
                                                            //console.log("gcm_key "+result.gcm_key);
                                                            constant.gcm.Sender(result.gcm_key).sendNoRetry(message, { registrationTokens: [res[1].payload.token] }, function (err, res) {
                                                                //response.end(ConstantMethod.sucess((data.r_userId==res[0]._id)?res[0]:res[1]));
                                                                //response.end(ConstantMethod.sucess(res));
                                                                //console.log("Success "+res);
                                                            })

                                                            //constant.sender.sendNoRetry(message,
                                                            //	{registrationTokens: [(data.r_userId==res[0]._id)?res[0].payload.token:res[1].payload.token]}, function (err, response) {
                                                            //
                                                            //	});
                                                        } else {
                                                            //console.log("else gcm_key "+result.gcm_key);
                                                            constant.sender.sendNoRetry(message, { registrationTokens: [res[1].payload.token] }, function (err, response) {})
                                                        }
                                                    })
                                                }
                                            } else {
                                                //console.log("Messgae : "+JSON.stringify(message));
                                                //console.log("No package_name");
                                                //console.log("data  "+JSON.stringify(res));
                                                //console.log("else RES "+res);

                                                if (res[0] != null && res[1] != null) {
                                                    //console.log("res[0]+res[1]");
                                                    constant.sender.sendNoRetry(message, { registrationTokens: [data.r_userId == res[0]._id ? res[0].payload.token : res[1].payload.token] }, function (err, response) {})
                                                } else if (res[0] != null) {
                                                    //console.log("res[0]");
                                                    constant.sender.sendNoRetry(message, { registrationTokens: [res[0].payload.token] }, function (err, response) {})
                                                } else if (res[1] != null) {
                                                    //console.log("res[1]");
                                                    constant.sender.sendNoRetry(message, { registrationTokens: [res[1].payload.token] }, function (err, response) {})
                                                }
                                            }
                                        }
                                    })
                                }
                            })
                        } else if (su != null && su.payload != null && su.payload.hasOwnProperty("master_id")) {
                            //if(su.payload.hasOwnProperty("master_id") && su.payload.master_id=="60cada7ddc21013c7fa1b2c4")
                            //	console.log("Host Call "+JSON.stringify(su));

                            var ru = su._id == res[0]._id ? res[1] : res[0]

                            if (ru.payload.Coin != null && ru.payload.package_name != null && ru.payload.app_version != null && ru.payload.package_name == "com.videocall.randomcallapps" && ru.payload.Coin > 0) {
                                //console.log("data  "+JSON.stringify(data));
                                var temp_data = {}
                                temp_data["userId"] = data.r_userId
                                temp_data["status"] = 1
                                temp_data["push"] = 1

                                var batch = constant.MongoDb.liveuser.initializeUnorderedBulkOp({ useLegacyOps: true })
                                batch.find({ _id: data.s_userId }).updateOne({ $set: { "payload.status": 1 } })

                                batch
                                    .find({ _id: data.r_userId })
                                    .upsert()
                                    .updateOne({ $set: { payload: temp_data } })
                                batch.execute(function (err, result) {
                                    if (!err) {
                                        constant.MongoDb.ice_server.findOne({}, function (err, iceres) {
                                            if (!err && iceres != null) {
                                                data["s_socketId"] = socket.id
                                                data["eventName"] = "LivevideoPush"
                                                data["date"] = constant.CurrentTimeStamp()
                                                data["ice_server"] = JSON.stringify(iceres)

                                                //data['host_name'] = res[0].payload.hasOwnProperty('host_name')
                                                if (res[0] != null && res[0].payload.hasOwnProperty("host_name")) {
                                                    data["host_name"] = res[0].payload.host_name
                                                } else if (res[1] != null && res[1].payload.hasOwnProperty("host_name")) {
                                                    data["host_name"] = res[1].payload.host_name
                                                }

                                                let message = new constant.gcm.Message({
                                                    data: { data },
                                                })
                                                //if(res[0]!=null&&res[1]!=null&&(res[0]._id=="108374367725590581752"||res[0]._id=="108374367725590581752"))
                                                //	console.log("data  "+JSON.stringify(data));

                                                if (data.hasOwnProperty("package_name")) {
                                                    //console.log("With package_name");
                                                    if (res[0] != null && res[1] != null) {
                                                        constant.MongoDb.package.findOne({ package_name: data.r_userId == res[0]._id ? res[0].payload.package_name : res[1].payload.package_name }, function (err, result) {
                                                            if (result != null) {
                                                                //console.log("gcm_key "+result.gcm_key);
                                                                constant.gcm.Sender(result.gcm_key).sendNoRetry(message, { registrationTokens: [data.r_userId == res[0]._id ? res[0].payload.token : res[1].payload.token] }, function (err, res) {
                                                                    //response.end(ConstantMethod.sucess((data.r_userId==res[0]._id)?res[0]:res[1]));
                                                                    //response.end(ConstantMethod.sucess(res));
                                                                    //console.log("Success "+res);
                                                                })

                                                                //constant.sender.sendNoRetry(message,
                                                                //	{registrationTokens: [(data.r_userId==res[0]._id)?res[0].payload.token:res[1].payload.token]}, function (err, response) {
                                                                //
                                                                //	});
                                                            } else {
                                                                //console.log("else gcm_key "+result.gcm_key);
                                                                constant.sender.sendNoRetry(message, { registrationTokens: [data.r_userId == res[0]._id ? res[0].payload.token : res[1].payload.token] }, function (err, response) {})
                                                            }
                                                        })
                                                    } else if (res[0] != null) {
                                                        constant.MongoDb.package.findOne({ package_name: res[0].payload.package_name }, function (err, result) {
                                                            if (result != null) {
                                                                //console.log("gcm_key "+result.gcm_key);
                                                                constant.gcm.Sender(result.gcm_key).sendNoRetry(message, { registrationTokens: [res[0].payload.token] }, function (err, res) {
                                                                    //response.end(ConstantMethod.sucess((data.r_userId==res[0]._id)?res[0]:res[1]));
                                                                    //response.end(ConstantMethod.sucess(res));
                                                                    //console.log("Success "+res);
                                                                })

                                                                //constant.sender.sendNoRetry(message,
                                                                //	{registrationTokens: [(data.r_userId==res[0]._id)?res[0].payload.token:res[1].payload.token]}, function (err, response) {
                                                                //
                                                                //	});
                                                            } else {
                                                                //console.log("else gcm_key "+result.gcm_key);
                                                                constant.sender.sendNoRetry(message, { registrationTokens: [res[0].payload.token] }, function (err, response) {})
                                                            }
                                                        })
                                                    } else if (res[1] != null) {
                                                        constant.MongoDb.package.findOne({ package_name: res[1].payload.package_name }, function (err, result) {
                                                            if (result != null) {
                                                                //console.log("gcm_key "+result.gcm_key);
                                                                constant.gcm.Sender(result.gcm_key).sendNoRetry(message, { registrationTokens: [res[1].payload.token] }, function (err, res) {
                                                                    //response.end(ConstantMethod.sucess((data.r_userId==res[0]._id)?res[0]:res[1]));
                                                                    //response.end(ConstantMethod.sucess(res));
                                                                    //console.log("Success "+res);
                                                                })

                                                                //constant.sender.sendNoRetry(message,
                                                                //	{registrationTokens: [(data.r_userId==res[0]._id)?res[0].payload.token:res[1].payload.token]}, function (err, response) {
                                                                //
                                                                //	});
                                                            } else {
                                                                //console.log("else gcm_key "+result.gcm_key);
                                                                constant.sender.sendNoRetry(message, { registrationTokens: [res[1].payload.token] }, function (err, response) {})
                                                            }
                                                        })
                                                    }
                                                } else {
                                                    //console.log("Messgae : "+JSON.stringify(message));
                                                    //console.log("No package_name");
                                                    //console.log("data  "+JSON.stringify(res));
                                                    //console.log("else RES "+res);

                                                    if (res[0] != null && res[1] != null) {
                                                        //console.log("res[0]+res[1]");
                                                        constant.sender.sendNoRetry(message, { registrationTokens: [data.r_userId == res[0]._id ? res[0].payload.token : res[1].payload.token] }, function (err, response) {})
                                                    } else if (res[0] != null) {
                                                        //console.log("res[0]");
                                                        constant.sender.sendNoRetry(message, { registrationTokens: [res[0].payload.token] }, function (err, response) {})
                                                    } else if (res[1] != null) {
                                                        //console.log("res[1]");
                                                        constant.sender.sendNoRetry(message, { registrationTokens: [res[1].payload.token] }, function (err, response) {})
                                                    }
                                                }
                                            }
                                        })
                                    }
                                })
                            } else {
                                data["eventName"] = "FinishSingleCall"
                                socket.emit("VideoClient", data)
                                //console.log("USer Have NO Coin Babby--->  "+JSON.stringify(ru));
                            }
                        }
                    } else {
                        data["eventName"] = "FinishSingleCall"
                        socket.emit("VideoClient", data)
                    }
                })
            }
        })
    },
    JoinRoom: function (data, constant, socket) {
        constant.MongoDb.liveuser.find({ _id: data.s_userId }).toArray(function (err, res) {
            if (!err && res != null && res.length > 0) {
                let result = res[0]
                result["userId"] = data.r_userId
                _this.StatusFriend(data, constant, result, function (StatusResult) {
                    data["status"] = StatusResult

                    data["OtherSocketId"] = socket.id

                    data["eventName"] = "JoinRoom"
                    constant.io.to(result.payload.SocketId).emit("VideoClient", data)
                })
            } else {
                //if sender is offline
                data["eventName"] = "FinishSingleCall"
                socket.emit("VideoClient", data)
            }
        })
    },
    CallSetup: function (data, constant, socket) {
        constant.MongoDb.liveuser.find({ _id: data.r_userId }).toArray(function (err, res) {
            if (!err && res != null && res.length > 0) {
                let result = res[0]
                //is receiver is online but not in call then lock sender and receiver both
                // data["OtherSocketId"] = socket.id;
                // data["eventName"] = 'CallSetup';
                result["userId"] = data.s_userId
                _this.StatusFriend(data, constant, result, function (StatusResult) {
                    data["OtherSocketId"] = socket.id
                    data["eventName"] = "CallSetup"
                    data["status"] = StatusResult
                    constant.io.to(result.payload.SocketId).emit("VideoClient", data)
                })
                // constant.io.to(result.payload.SocketId).emit('VideoClient', data);
            } else {
                //if sender is offline
                data["eventName"] = "FinishSingleCall"
                socket.emit("VideoClient", data)
            }
        })
    },
    hangup: function (data, constant, socket) {
        constant.MongoDb.liveuser.find({ _id: data.OtherUserId }).toArray(function (err, result) {
            var userId = []

            if (data.hasOwnProperty("Push")) {
                /*receiver cut the call by him self when he comes with push*/
                _this.RemoveByPush(data.userId, constant, socket)
                userId.push(data.OtherUserId)
            } else if (result != null && result.length > 0 && result[0].payload.hasOwnProperty("push")) {
                /*app killed by user who not come with push but otheruser is come with push*/
                userId.push(data.userId)
                _this.RemoveByPush(data.OtherUserId, constant, socket)
            } else {
                /*both are come with normal call.*/
                userId.push(data.userId)
                userId.push(data.OtherUserId)
            }

            constant.MongoDb.liveuser.updateMany({ _id: { $in: userId } }, { $set: { "payload.status": 0 } }, function (err, res) {
                if (!err) {
                    if (result != null && result.length > 0) constant.io.to(result[0].payload.SocketId).emit("VideoClient", data)

                    if (data.hasOwnProperty("OthersocketId")) {
                        if (data.hasOwnProperty("IsSignupUser")) {
                            constant.MongoDb.user.findOne({ _id: data.OtherUserId }, function (err, result) {
                                /**this is for history entry*/
                                if (!err && result != null) {
                                    let historyuser = {}
                                    historyuser[data.userId] = data.OtherUserId
                                    historyuser[data.OtherUserId] = data.userId

                                    Object.keys(historyuser).forEach(function (k) {
                                        let currentUser = k
                                        let OtherUser = historyuser[k]

                                        constant.MongoDb.history.aggregate([{ $match: { _id: currentUser } }, { $project: { hasOtherUser: { $in: [OtherUser, "$payload.caller.id"] } } }]).toArray(function (err, res) {
                                            if (!err && res != null && res.length > 0) {
                                                let currentUser = null
                                                let OtherUser = null
                                                if (res[0]._id === data.userId) {
                                                    currentUser = data.userId
                                                    OtherUser = data.OtherUserId
                                                } else {
                                                    OtherUser = data.userId
                                                    currentUser = data.OtherUserId
                                                }

                                                if (res[0].hasOtherUser) {
                                                    constant.MongoDb.history.updateOne(
                                                        {
                                                            _id: currentUser,
                                                            "payload.caller.id": OtherUser,
                                                        },
                                                        {
                                                            $set: {
                                                                "payload.caller.$.duration": data.duration,
                                                                "payload.caller.$.date": constant.CurrentTimeStamp(),
                                                            },
                                                        },
                                                        { upsert: true },
                                                        function (err, res) {}
                                                    )
                                                } else {
                                                    constant.MongoDb.history.updateOne(
                                                        { _id: currentUser },
                                                        {
                                                            $push: {
                                                                "payload.caller": {
                                                                    $each: [
                                                                        {
                                                                            id: OtherUser,
                                                                            duration: data.duration,
                                                                            date: constant.CurrentTimeStamp(),
                                                                        },
                                                                    ],
                                                                    $slice: -50,
                                                                },
                                                            },
                                                        },
                                                        { upsert: true },
                                                        function (err, res) {}
                                                    )
                                                }
                                            } else {
                                                var dataObj = {
                                                    _id: currentUser,
                                                    payload: {
                                                        caller: [
                                                            {
                                                                id: OtherUser,
                                                                duration: data.duration,
                                                                date: constant.CurrentTimeStamp(),
                                                            },
                                                        ],
                                                    },
                                                }

                                                constant.MongoDb.history.insertOne(dataObj, function (err, res) {})
                                            }
                                        })
                                    })
                                }
                            })
                        }
                        data.eventName = "hangup"
                        constant.io.to(data.OthersocketId).emit("VideoClient", data)
                    }

                    // if ('Push' in data) {
                    //     _this.RemoveByPush(data, constant, socket);
                    // }
                    // //is receiver is online but not in call then lock sender and receiver both
                    // // if ('OthersocketId' in data)
                    // if (result.length > 0) {
                    //
                    //     constant.io.to(result[0].payload.SocketId).emit('VideoClient', data);
                    // }
                }
            })
        })
    },
    RemoveByPush: function (userId, constant, socket) {
        constant.MongoDb.liveuser.deleteMany({ _id: userId }, function (err, res) {})
    },
    RandomHangup: function (data, constant, socket) {
        let userId = [data.userId]
        if (data.hasOwnProperty("OtherUserId")) {
            userId.push(data.OtherUserId)
        }

        constant.MongoDb.liveuser.deleteMany({ _id: { $in: userId } }, function (err, res) {
            if (data.hasOwnProperty("OthersocketId")) {
                if (data.hasOwnProperty("IsSignupUser")) {
                    constant.MongoDb.user.findOne({ _id: data.OtherUserId }, function (err, result) {
                        /**this is for history entry*/
                        if (!err && result != null) {
                            let historyuser = {}
                            historyuser[data.userId] = data.OtherUserId
                            historyuser[data.OtherUserId] = data.userId

                            Object.keys(historyuser).forEach(function (k) {
                                let currentUser = k
                                let OtherUser = historyuser[k]

                                constant.MongoDb.history.aggregate([{ $match: { _id: currentUser } }, { $project: { hasOtherUser: { $in: [OtherUser, "$payload.caller.id"] } } }]).toArray(function (err, res) {
                                    if (!err && res != null && res.length > 0) {
                                        let currentUser = null
                                        let OtherUser = null
                                        if (res[0]._id === data.userId) {
                                            currentUser = data.userId
                                            OtherUser = data.OtherUserId
                                        } else {
                                            OtherUser = data.userId
                                            currentUser = data.OtherUserId
                                        }

                                        if (res[0].hasOtherUser) {
                                            constant.MongoDb.history.updateOne(
                                                { _id: currentUser, "payload.caller.id": OtherUser },
                                                {
                                                    $set: {
                                                        "payload.caller.$.duration": data.duration,
                                                        "payload.caller.$.date": constant.CurrentTimeStamp(),
                                                    },
                                                },
                                                { upsert: true },
                                                function (err, res) {}
                                            )
                                        } else {
                                            constant.MongoDb.history.updateOne(
                                                { _id: currentUser },
                                                {
                                                    $push: {
                                                        "payload.caller": {
                                                            $each: [
                                                                {
                                                                    id: OtherUser,
                                                                    duration: data.duration,
                                                                    date: constant.CurrentTimeStamp(),
                                                                },
                                                            ],
                                                            $slice: -50,
                                                        },
                                                    },
                                                },
                                                { upsert: true },
                                                function (err, res) {}
                                            )
                                        }
                                    } else {
                                        var dataObj = {
                                            _id: currentUser,
                                            payload: {
                                                caller: [
                                                    {
                                                        id: OtherUser,
                                                        duration: data.duration,
                                                        date: constant.CurrentTimeStamp(),
                                                    },
                                                ],
                                            },
                                        }

                                        constant.MongoDb.history.insertOne(dataObj, function (err, res) {})
                                    }
                                })
                            })
                        }
                    })
                }
                data.eventName = "hangup"
                constant.io.to(data.OthersocketId).emit("VideoClient", data)
            }
        })
    },
    RandomAudioHangup: function (data, constant, socket) {
        console.log("RandomAudioHangup --->   " + data)
        let userId = [data.userId]
        if (data.hasOwnProperty("OtherUserId")) {
            userId.push(data.OtherUserId)
        }

        constant.MongoDb.liveuser_audio.deleteMany({ _id: { $in: userId } }, function (err, res) {
            if (data.hasOwnProperty("OthersocketId")) {
                if (data.hasOwnProperty("IsSignupUser")) {
                    constant.MongoDb.user.findOne({ _id: data.OtherUserId }, function (err, result) {
                        /**this is for history entry*/
                        if (!err && result != null) {
                            let historyuser = {}
                            historyuser[data.userId] = data.OtherUserId
                            historyuser[data.OtherUserId] = data.userId

                            Object.keys(historyuser).forEach(function (k) {
                                let currentUser = k
                                let OtherUser = historyuser[k]

                                constant.MongoDb.history_audio.aggregate([{ $match: { _id: currentUser } }, { $project: { hasOtherUser: { $in: [OtherUser, "$payload.caller.id"] } } }]).toArray(function (err, res) {
                                    if (!err && res != null && res.length > 0) {
                                        let currentUser = null
                                        let OtherUser = null
                                        if (res[0]._id === data.userId) {
                                            currentUser = data.userId
                                            OtherUser = data.OtherUserId
                                        } else {
                                            OtherUser = data.userId
                                            currentUser = data.OtherUserId
                                        }

                                        if (res[0].hasOtherUser) {
                                            constant.MongoDb.history_audio.updateOne(
                                                { _id: currentUser, "payload.caller.id": OtherUser },
                                                {
                                                    $set: {
                                                        "payload.caller.$.duration": data.duration,
                                                        "payload.caller.$.date": constant.CurrentTimeStamp(),
                                                    },
                                                },
                                                { upsert: true },
                                                function (err, res) {}
                                            )
                                        } else {
                                            constant.MongoDb.history_audio.updateOne(
                                                { _id: currentUser },
                                                {
                                                    $push: {
                                                        "payload.caller": {
                                                            $each: [
                                                                {
                                                                    id: OtherUser,
                                                                    duration: data.duration,
                                                                    date: constant.CurrentTimeStamp(),
                                                                },
                                                            ],
                                                            $slice: -50,
                                                        },
                                                    },
                                                },
                                                { upsert: true },
                                                function (err, res) {}
                                            )
                                        }
                                    } else {
                                        if (data.hasOwnProperty("isAudioCall")) {
                                            var dataObj = {
                                                _id: currentUser,
                                                payload: {
                                                    caller: [
                                                        {
                                                            id: OtherUser,
                                                            duration: data.duration,
                                                            isAudioCall: data.isAudioCall,
                                                            date: constant.CurrentTimeStamp(),
                                                        },
                                                    ],
                                                },
                                            }
                                        } else {
                                            var dataObj = {
                                                _id: currentUser,
                                                payload: {
                                                    caller: [
                                                        {
                                                            id: OtherUser,
                                                            duration: data.duration,
                                                            date: constant.CurrentTimeStamp(),
                                                        },
                                                    ],
                                                },
                                            }
                                        }

                                        constant.MongoDb.history_audio.insertOne(dataObj, function (err, res) {})
                                    }
                                })
                            })
                        }
                    })
                }
                data.eventName = "hangup"
                constant.io.to(data.OthersocketId).emit("VideoClient", data)
            }
        })
    },

    DisContinue: function (data, constant, socket) {
        //console.log("---DisContinue--"+JSON.stringify(data));

        let dummyData = JSON.parse(JSON.stringify(data))
        dummyData.eventName = "RandomCall"
        delete dummyData["OtherUserId"]
        _this.RandomCall(dummyData, constant, socket, function () {
            if (data.hasOwnProperty("OtherUserId")) {
                constant.MongoDb.liveuser.findOne({ _id: data.OtherUserId }, function (err, res) {
                    if (!err && res != null) {
                        data.eventName = "DisContinue"
                        // console.log(data);
                        constant.io.to(res.payload.SocketId).emit("VideoClient", data)
                    }
                    if (data.hasOwnProperty("IsSignupUser")) {
                        constant.MongoDb.user.findOne({ _id: data.OtherUserId }, function (err, result) {
                            /**this is for history entry*/
                            if (!err && result != null) {
                                let historyuser = {}
                                historyuser[data.userId] = data.OtherUserId
                                historyuser[data.OtherUserId] = data.userId

                                Object.keys(historyuser).forEach(function (k) {
                                    let currentUser = k
                                    let OtherUser = historyuser[k]

                                    constant.MongoDb.history.aggregate([{ $match: { _id: currentUser } }, { $project: { hasOtherUser: { $in: [OtherUser, "$payload.caller.id"] } } }]).toArray(function (err, res) {
                                        if (!err && res != null && res.length > 0) {
                                            let currentUser = null
                                            let OtherUser = null
                                            if (res[0]._id === data.userId) {
                                                currentUser = data.userId
                                                OtherUser = data.OtherUserId
                                            } else {
                                                OtherUser = data.userId
                                                currentUser = data.OtherUserId
                                            }

                                            if (res[0].hasOtherUser) {
                                                constant.MongoDb.history.updateOne(
                                                    { _id: currentUser, "payload.caller.id": OtherUser },
                                                    {
                                                        $set: {
                                                            "payload.caller.$.duration": data.duration,
                                                            "payload.caller.$.date": constant.CurrentTimeStamp(),
                                                        },
                                                    },
                                                    { upsert: true },
                                                    function (err, res) {}
                                                )
                                            } else {
                                                constant.MongoDb.history.updateOne(
                                                    { _id: currentUser },
                                                    {
                                                        $push: {
                                                            "payload.caller": {
                                                                $each: [
                                                                    {
                                                                        id: OtherUser,
                                                                        duration: data.duration,
                                                                        date: constant.CurrentTimeStamp(),
                                                                    },
                                                                ],
                                                                $slice: -50,
                                                            },
                                                        },
                                                    },
                                                    { upsert: true },
                                                    function (err, res) {}
                                                )
                                            }
                                        } else {
                                            var dataObj = {
                                                _id: currentUser,
                                                payload: {
                                                    caller: [
                                                        {
                                                            id: OtherUser,
                                                            duration: data.duration,
                                                            date: constant.CurrentTimeStamp(),
                                                        },
                                                    ],
                                                },
                                            }

                                            constant.MongoDb.history.insertOne(dataObj, function (err, res) {})
                                        }
                                    })
                                })
                            }
                        })
                    }
                })
            }
        })
    },
    MultipleBatch: function (data, constant, socket, callback) {
        constant.MongoDb.friend.find({ _id: { $in: [data.userId, data.ReqUserId] } }).toArray(function (err, res) {
            if (!err && res != null) {
                let batch = constant.MongoDb.friend.initializeUnorderedBulkOp({ useLegacyOps: true })
                if (res != null && res.length > 1) {
                    constant.MongoDb.friend.findOne(
                        {
                            _id: data.userId,
                            "payload.pending": { $in: [data.ReqUserId] },
                        },
                        function (err, res) {
                            if (res === null) {
                                batch.find({ _id: data.userId }).updateOne({ $addToSet: { "payload.sent": data.ReqUserId } })
                                batch.find({ _id: data.ReqUserId }).updateOne({ $addToSet: { "payload.pending": data.userId } })
                                callback(batch)
                            } else {
                                callback(null)
                                // response.status(500).send(ConstantMethod.Error(err));
                            }
                        }
                    )
                } else if (res != null && res.length > 0) {
                    if (res[0]._id === data.userId) {
                        constant.MongoDb.friend.findOne(
                            {
                                _id: data.userId,
                                "payload.pending": { $in: [data.ReqUserId] },
                            },
                            function (err, res) {
                                if (res == null) {
                                    batch.find({ _id: data.userId }).updateOne({ $addToSet: { "payload.sent": data.ReqUserId } })
                                    batch.insert({
                                        _id: data.ReqUserId,
                                        payload: {
                                            sent: [],
                                            pending: [data.userId],
                                            accepted: [],
                                            rejected: [],
                                            rejectedByOther: [],
                                        },
                                    })
                                    callback(batch)
                                } else {
                                    // response.status(500).send(ConstantMethod.Error(err));
                                    callback(null)
                                }
                            }
                        )
                    } else {
                        constant.MongoDb.friend.findOne(
                            {
                                _id: data.ReqUserId,
                                "payload.sent": { $in: [data.userId] },
                            },
                            function (err, res) {
                                if (res == null) {
                                    batch.find({ _id: data.ReqUserId }).updateOne({ $addToSet: { "payload.pending": data.userId } })
                                    batch.insert({
                                        _id: data.userId,
                                        payload: {
                                            sent: [data.ReqUserId],
                                            pending: [],
                                            accepted: [],
                                            rejected: [],
                                            rejectedByOther: [],
                                        },
                                    })
                                    callback(batch)
                                } else {
                                    // response.status(500).send(ConstantMethod.Error(err));
                                    callback(null)
                                }
                            }
                        )
                    }
                } else {
                    batch.insert({
                        _id: data.userId,
                        payload: {
                            sent: [data.ReqUserId],
                            pending: [],
                            accepted: [],
                            rejected: [],
                            rejectedByOther: [],
                        },
                    })
                    batch.insert({
                        _id: data.ReqUserId,
                        payload: {
                            sent: [],
                            pending: [data.userId],
                            accepted: [],
                            rejected: [],
                            rejectedByOther: [],
                        },
                    })
                    callback(batch)
                }
            } else {
                // response.status(500).send(ConstantMethod.Error(err));
                callback(null)
            }
        })
    },
    SendFriendReq: function (data, constant, socket) {
        _this.MultipleBatch(data, constant, socket, function (batch) {
            if (batch == null) {
                constant.io.to(data.SocketId).emit("VideoClient", { eventName: "Reqstatus", status: 0 })
            } else
                batch.execute(function (err, res) {
                    if (!err) {
                        socket.emit("VideoClient", { eventName: "Reqstatus", status: 2 })
                        constant.io.to(data.SocketId).emit("VideoClient", { eventName: "Reqstatus", status: 0 })
                    } else {
                        constant.io.to(data.SocketId).emit("VideoClient", { eventName: "Reqstatus", status: 0 })
                    }
                })
        })
    },
    RequestAccept: function (data, constant, socket) {
        let batch = constant.MongoDb.friend.initializeUnorderedBulkOp({ useLegacyOps: true })

        batch.find({ _id: data.userId }).updateOne({
            $addToSet: { "payload.accepted": data.ReqUserId },
            $pull: { "payload.pending": data.ReqUserId },
        })
        batch.find({ _id: data.ReqUserId }).updateOne({
            $addToSet: { "payload.accepted": data.userId },
            $pull: { "payload.sent": data.userId },
        })

        batch.execute(function (err, res) {
            if (!err) {
                socket.emit("VideoClient", { eventName: "Reqstatus", status: 4 })
                constant.io.to(data.SocketId).emit("VideoClient", { eventName: "Reqstatus", status: 4 })
                // response.end(ConstantMethod.sucess(JSON.stringify(Data)));
            }
        })
    },
    StatusFriend: function (data, constant, result, callback) {
        // if (data.IsRandom) {
        constant.MongoDb.friend
            .aggregate([
                { $match: { _id: result._id } },
                {
                    $project: {
                        ReqStatus: {
                            $cond: [
                                { $gt: ["$payload", null] },
                                {
                                    $cond: [
                                        { $in: [result.userId, "$payload.pending"] },
                                        0,
                                        {
                                            $cond: [
                                                { $in: [result.userId, "$payload.rejected"] },
                                                1,
                                                {
                                                    $cond: [
                                                        { $in: [result.userId, "$payload.sent"] },
                                                        2,
                                                        {
                                                            $cond: [
                                                                { $in: [result.userId, "$payload.rejectedByOther"] },
                                                                3,
                                                                {
                                                                    $cond: [{ $in: [result.userId, "$payload.accepted"] }, 4, -1],
                                                                },
                                                            ],
                                                        },
                                                    ],
                                                },
                                            ],
                                        },
                                    ],
                                },
                                -1,
                            ],
                        },
                    },
                },
            ])
            .toArray(function (err, res) {
                if (!err && res != null && res.length > 0) {
                    callback(res[0].ReqStatus)
                } else {
                    constant.MongoDb.user.findOne(
                        {
                            _id: result._id,
                        },
                        function (err, res) {
                            if (!err && res !== null) {
                                callback(-1) //this is for skip user
                            } else {
                                callback(-2) //this is for skip user
                            }
                        }
                    )
                }
            })
        // } else
        //     callback(-2)//this is for skip user
    },
})

// , GoPromies: function (data, constant, socket) {
//     return new Promise(function (resolve, reject) {
//         constant.MongoDb.liveuser.find({_id: data.r_userId}).toArray(
//             function (err, res) {
//
//                 // console.log('Create call result >>>>> ', data.r_userId)
//                 if (!err && res.length > 0) {
//                     resolve(res[0]);
//                     if (res[0].payload.status === 1) {
//                         //is receiver is online
//                         console.log(res[0].payload.status);
//                     } else {
//                         //send push notification
//                         console.log(res[0].payload.status);
//                     }
//                 } else {
//                     reject("User not found!!")
//                 }
//
//             })
//     });
