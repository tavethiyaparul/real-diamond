/**
 * Created by manoj miyani on 09/05/15.
 */
/******************************************/
"use strict";
let constant = null;
let ConstantMethod = require('../Utils/ConstantMethod');
let ChatEvent = require('../Event/ChatEvent');
var _this = module.exports = {

    init: function (_constant) {
        constant = _constant;
        setEventHandlers();

    }
};

function setEventHandlers() {
   // console.log('setEventHandlers called !! ');

    constant.io.on("connection", function (socket) {
       // console.log('Socket conneced !! -->', socket.id);

        socket.on('ChatServer', function (data) {
           // console.log('>>> INPUT DATA >>>>> ', data);
            if (data === null)
                return
            if (data.eventName === 'UserStatus') {
                ChatEvent.UserStatus(data, constant, socket);
            } else if (data.eventName === 'IsOnline') {
                ChatEvent.IsOnline(data, constant, socket);
            } else if (data.eventName === 'IsChatExist') {
                ChatEvent.IsChatExist(data, constant, socket);
            } else if (data.eventName === 'Chatting') {
                ConstantMethod.WriteFile(data, constant, socket);
            } else if (data.eventName === 'TickUpdate') {
                ConstantMethod.TickUpdate(data, constant, socket);
            } else if (data.eventName === 'SendAgain') {
                ConstantMethod.SendAgain(data, constant, socket);
            } else if (data.eventName === 'UpdateReceiverTick') {
                ConstantMethod.UpdateReceiverTick(data, constant, socket);
            } else if (data.eventName === 'userTyping') {
                ConstantMethod.userTyping(data, constant, socket);
            }  else if (data.eventName === 'chat') {
                constant.io.to(data.SocketId).emit('VideoClient', data);
            } else if (data.eventName === 'mediaDelete') {
                constant.ensureDirectoryExistence([constant.Proj_dir + "/Resource/TempFile/" + data.path], function (path) {
                    if (path != null) {
                        try{
                            constant.fs.unlinkSync(path);
                        }
                        catch (error) { 
                         // your catch block code goes here
                        }
                    }
                });

            } else if (data.eventName === 'userOffline') {
                // socket.broadcast.emit('VideoClient',
                //     {eventName: "IsOnline", OtherUserId: data.userId, status: 0}
                // );
                constant.MongoDb.friend.aggregate([
                    {$match: {_id: data.userId}}
                    ,
                    {
                        $lookup:
                            {
                                from: 'liveuser',
                                localField: 'payload.accepted',
                                foreignField: '_id',
                                as: 'UserObj'
                            }
                    },
                    {$unwind: {path: '$UserObj', preserveNullAndEmptyArrays: true}},
                    {$project: {UserObj: 1}},
                    {"$replaceRoot": {"newRoot": {"$mergeObjects": ["$UserObj.payload"]}}}
                ]).toArray(function (err, res) {
                    if (!err && res != null && res.length > 0) {
                        for (let key in res) {
                            let value = res[key]; // get the value by key
                            constant.io.to(value.SocketId).emit('VideoClient', {
                                eventName: "IsOnline",
                                OtherUserId: data.userId,
                                status: 0
                            });
                        }
                    }

                });
                constant.MongoDb.liveuser.deleteMany(
                    {_id: data.userId}
                    , function (err, res) {


                    });
            }

        });
    });
}


