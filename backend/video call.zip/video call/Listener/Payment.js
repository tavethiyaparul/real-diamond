/**
 * Created by manoj miyani on 09/05/15.
 */
/******************************************/
"use strict";
let constant = null;

let PaymentEvent = require('../Event/PaymentEvent');
var _this = module.exports = {

    init: function (_constant) {
        constant = _constant;
        setEventHandlers();

    }
};

function setEventHandlers() {
   // console.log('Payment Listener called !! ');

    constant.io.on("connection", function (socket) {
        //console.log('Socket conneced !! -->', socket.id);

        socket.on('PaymentServer', function (data) {
            // console.log('>>> INPUT DATA >>>>> ', data);
            if (data === null)
                return
            if (data.eventName === 'CoinDeduct') {
                PaymentEvent.CoinDeduct(data, constant, socket);
            }else if (data.eventName === 'isUserAgent') {
                PaymentEvent.isUserAgent(data, constant, socket);
            }
			else if (data.eventName === 'HostCoinCheck') {
                PaymentEvent.HostCoinCheck(data, constant, socket);
            }

        });
    });
}


