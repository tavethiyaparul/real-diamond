"use strict";
let constant = require('./Utils/constant');
let VideoEvent = require('./Event/VideoEvent');
// let UserRegistered = require('./API/VideoAPI');
let Chat = require('./Listener/Chat');
let Payment = require('./Listener/Payment');

/*User registered call*/
// UserRegistered.VideoAPI(constant);
setEventHandlers();
Chat.init(constant);
Payment.init(constant);

function setEventHandlers() {

    constant.io.on("connection", function (socket) {

        //constant.io.emit('message', "this is a test"); //sending to sender-client only
        //console.log('>>>message>>>>> ');
        socket.on('VideoServer', function (data) {
            //console.log("VideoServer");
            //  console.log('>>> INPUT DATA >>>>> ', data);
            // if (data.eventName === 'UserStatus') {
            //     VideoEvent.UserStatus(data, constant, socket, null);
            // } else
            if (data.eventName === 'CurrentTimeStamp') {
                VideoEvent.CurrentTimeStamp(data, constant, socket);
            }else if (data.eventName === 'FakeVideo') {
            VideoEvent.FakeVideo(data, constant, socket);
            }else if (data.eventName === 'HostIsOnline') {
                VideoEvent.HostIsOnline(data, constant, socket);
            } else if (data.eventName === 'Status') {
                VideoEvent.Status(data, constant, socket, null);
            } else if (data.eventName === 'UpdateSocket') {
                VideoEvent.UpdateSocket(data, constant, socket, null);
            } else if (data.eventName === 'CreateCall') {
                //emit send from sender side
                VideoEvent.CreateCall(data, constant, socket);
            } else if (data.eventName === 'ByPush') {
                //emit send from sender side
                VideoEvent.ByPush(data, constant, socket);
            } else if (data.eventName === 'JoinRoom') {
                //emit getting from receiver side
                VideoEvent.JoinRoom(data, constant, socket);
            } else if (data.eventName === 'CallSetup') {
                //emit getting from sender side
                VideoEvent.CallSetup(data, constant, socket);
            } else if (data.eventName === 'hangup') {
                //emit getting from sender side
                VideoEvent.hangup(data, constant, socket);
            } else if (data.eventName === 'RemoveByPush') {
                //emit getting from sender side
                VideoEvent.RemoveByPush(data.userID, constant, socket);
            } else if (data.eventName === 'RandomHangup') {
                //emit getting from sender side
                VideoEvent.RandomHangup(data, constant, socket);
            } else if (data.eventName === 'SendFriendReq') {
                //emit getting from sender side
                VideoEvent.SendFriendReq(data, constant, socket);
            } else if (data.eventName === 'RequestAccept') {
                //emit getting from sender side
                VideoEvent.RequestAccept(data, constant, socket);
            } else if (data.eventName === 'RandomCall') {
                //emit getting from sender side
                VideoEvent.RandomCall(data, constant, socket, null);
            } else if (data.eventName === 'RandomCallAudio') {

                // console.log('>>> RandomCallAudio >>>>> ', JSON.stringify(data));
                //if (typeof data.audio !== 'undefined' && data.audio !== null){
                //   console.log('>>> RandomCallAudio Rout >>>>> ', JSON.stringify(data));
                //}

                //emit getting from sender side
                VideoEvent.RandomCallAudio(data, constant, socket, null);
            }else if (data.eventName === 'RandomAudioHangup') {

                // console.log('>>> RandomAudioHangup >>>>> ', JSON.stringify(data));
                //if (typeof data.audio !== 'undefined' && data.audio !== null){
                //   console.log('>>> RandomAudioHangup Rout >>>>> ', JSON.stringify(data));
                //}

                //emit getting from sender side
                VideoEvent.RandomAudioHangup(data, constant, socket, null);
            }else if (data.eventName === 'DisContinue') {
                //emit getting from sender side
                VideoEvent.DisContinue(data, constant, socket);
            } else if (data.eventName === 'candidate') {
                constant.io.to(data.socketId).emit('VideoClient', data);
            }

        });


        socket.on("disconnect", function () {
            //  console.log("disconnect", socket.id);

            constant.MongoDb.liveuser.findOne(
                {'payload.SocketId': socket.id}
                , function (err, res) {

                    if (!err && res != null) {


                        constant.MongoDb.user_masters.updateOne(
                            {"uid": res._id},
                            {$set: {"is_online": 0}}, function (err, result) {
                                // console.log("disconnect_master_id", res._id);
                            });


                        constant.MongoDb.friend.aggregate([
                            {$match: {_id: res._id}}
                            ,
                            {
                                $lookup:
                                    {
                                        from: 'liveuser',
                                        localField: 'payload.accepted',
                                        foreignField: '_id',
                                        as: 'UserObj'
                                    }
                            },
                            {$unwind: {path: '$UserObj', preserveNullAndEmptyArrays: true}},
                            {$project: {UserObj: 1}},
                            {"$replaceRoot": {"newRoot": {"$mergeObjects": ["$UserObj.payload"]}}}
                        ]).toArray(function (err, result) {
                            if (!err && result != null && result.length > 0) {
                                for (let key in result) {
                                    let value = result[key]; // get the value by key
                                    constant.io.to(value.SocketId).emit('VideoClient', {
                                        eventName: "IsOnline",
                                        OtherUserId: res._id,
                                        status: 0
                                    });
                                }
                            }

                        });
                    }


                    constant.MongoDb.liveuser.deleteMany(
                        {'payload.SocketId': socket.id}
                        , function (err, res) {


                        });

                });

                constant.MongoDb.liveuser_audio.findOne(
                {'payload.SocketId': socket.id}
                , function (err, res) {

                        constant.MongoDb.liveuser_audio.deleteMany(
                        {'payload.SocketId': socket.id}
                        , function (err, res) {


                        });
                });



        });

      
        socket.on("error", function(exception) {
           console.log("Sorry,error there seems to be an issue with the connection!  "+exception);
        });

  
    });


}