#!/bin/bash
#command '/home/manoj/Downloads/shell'  -f="ios_info"  -rf='"client_type": [0-9]\'  -r='"client_type": q221' -fi=/home/manoj/Downloads/google-services.json
# -f-->find text in file
#-rf-->find text in line number
#-r--->replace text with rf
#-fi-->input file

for i in "$@"
do
case $i in
  -rf=*|--reg_express_find=*)
    reg_express_find="${i#*=}"
    shift # past argument=value
    ;;
 -fi=*|--file=*)
    file="${i#*=}"
    shift # past argument=value
    ;;
    -f=*|--find=*)
    find="${i#*=}"
    shift # past argument=value
    ;;
    -r=*|--replace=*)
    replace="${i#*=}"
    shift # past argument=value
    ;;
    *)
          # unknown option
    ;;
esac
done
number=$(grep -n  "${find}" $file)

if [ -z "$number" ]
then
      exit 0
else
      number=$(echo $number| cut -d':' -f 1)
      sed -i "${number}s/\($reg_express_find)/${replace}/g"  $file
      #echo $reg_express_find
fi 