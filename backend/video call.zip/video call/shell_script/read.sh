#!/bin/sh
# This is a comment!


for i in "$@"
do
case $i in
  -rf=*|--reg_express_find=*)
    reg_express_find="${i#*=}"
    shift # past argument=value
    ;;
 -fi=*|--file=*)
    file="${i#*=}"
    shift # past argument=value
    ;;
    -f=*|--find=*)
    find="${i#*=}"
    shift # past argument=value
    ;;
    -r=*|--replace=*)
    replace="${i#*=}"
    shift # past argument=value
    ;;
    *)
          # unknown option
    ;;
esac
done

#this command find last 2 index line string from file
lastline=$(tail -n 1 $file)
if [ -z "$lastline" ]
then
exit 0
fi
#echo $lastline | grep -o -P '(?<=timestamp":").*?(?=",)'<--- this scrapped word in-between from string. ex: this is@ manoj. grep -o -P '(?<=is).*?(?=@)'/return 'is'
#awk '{print $1;}'<--- this is separate words by space and retunr find index word. ex this is.  return this , is both separate 
date=$(echo $lastline | grep -o -P '(?<=timestamp":").*?(?=",)' |  awk '{print $1;}')

#add 30+ day in date
date=$(date -d  "${date} -30 days" "+%Y-%m-%d")
#find line number where text is find
#firstline=$(grep -n  ${date} $file)


#if [ -z "$firstline" ]
#then
#      exit 0
#else
      #firstline=$(echo $firstline| cut -d':' -f 1)
      #lastline=$(wc -l $file| cut -d' ' -f 1)
#echo sed  -n ${firstline},${lastline}p $file

lastdatemili=$(date +%s --date=$date)
 is_comma=false
 printf '['
  tac $file | while IFS= read -r line; do
newdate=$( echo $line | grep -o -P '(?<=timestamp":").*?(?=")'|  awk '{print $1;}')
 
#echo $date

 if [ ! -z "$newdate" ] && [ $(date +%s --date=$newdate) -gt $lastdatemili ]
then
check_commaa=$([ $is_comma = true ] &&  echo "," || echo "")

   printf   $check_commaa"$line"'%s\n'
 
is_comma=true
else
   break
   fi

done  
 printf ']'

#fi 


