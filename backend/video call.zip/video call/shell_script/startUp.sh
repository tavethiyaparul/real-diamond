STATUS_COUNT=`forever list | grep -i /var/www/random_video/public_html/vc-api/index.js | wc -c`
#echo $STATUS_COUNT
if [ $STATUS_COUNT -gt 0 ]
then
	forever restart /var/www/random_video/public_html/VideoNodeLive/Video.js >/dev/null; forever restart /var/www/random_video/public_html/vc-api/index.js >/dev/null; forever restart /var/www/random_video/public_html/videocall_new/index.js >/dev/null
	#echo "restart"
else
	forever start /var/www/random_video/public_html/VideoNodeLive/Video.js >/dev/null; forever start /var/www/random_video/public_html/vc-api/index.js >/dev/null; forever start /var/www/random_video/public_html/videocall_new/index.js >/dev/null
	#echo "start"
fi	
