/**
 * Created by miyani on 3/27/18.
 */
"use strict"
let gcm = require("node-gcm")
let paymentAPI = require("../API/PaymentAPI")
//let ClenerAPI = require('../API/ClenerAPI');
let VideoAPI = require("../API/VideoAPI")
let nodemailer = require("nodemailer")
//todo change variable  name
let Proj_dir = "/var/www/random_video/public_html/VideoNodeLive"
//todo change db   name
let DB_collecation = "random_video"
let https = require("https")
let app = require("express")()
let cmd = require("node-cmd")
let mongoURL = "mongodb://localhost:27017"
let fs = require("fs")
let cors = require("cors")

/*merchant */
// let sender = new gcm.Sender('AAAAohJWHtc:APA91bHQ_OIY3Qv8mNvEVVYTAv_xcyDSENMBkhnSdkln4YDLYyaXO1hoSWb4K-tg6kCQLe8ewmAA4fEN2uQoPBn_7mSYOBvp5mL7Ca968FbRbKbdfWi_CpU5DFBF0O8GhKBnqFHIkERnmAMoj0eQkTiWm0N1yVay4w');
/*video calling*/
let sender = new gcm.Sender("AAAAr1gow_8:APA91bHt4anwOunVM1jpx24N7VQct970OlEU6RJUUPshJ1B34od-tZLeOFmE8CGbt_b6Czps_OeLWmz7nWkPW7l230Sl1XXA-m-1cJACafhQDaiUhyoT6tyGgWd16_afY7_JmVesKpP5")

let MongoDb = {}
let bodyParser = require("body-parser")
var multer = require("multer")

var mailtransporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
        user: "criscosoft@gmail.com",
        pass: "manoj23@",
    },
})

var mailOptions = {
    from: "criscosoft@gmail.com",
    to: "criscosoft@gmail.com",
    subject: "Report by user",
    text: "That was easy!",
}
let storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, Proj_dir + "/Resource/ProfilePic/")
    },
    filename: function (req, file, cb) {
        if (!file.originalname.match(/\.(jpg|jpeg|png)$/)) {
            cb(new Error("Only image files are allowed!"))
        } else cb(null, file.originalname)
    },
})
let FileUpload = multer({ storage: storage })

let credentials = {
    ca: fs.readFileSync("/cert/thevideocall_com.ca"),
    key: fs.readFileSync("/cert/server.key"),
    cert: fs.readFileSync("/cert/thevideocall_com.crt"),
    rejectUnauthorized: false,
}
app.use(bodyParser.json())
app.use(cors("*"))
//todo Change port here
let io = require("socket.io")(https.createServer(credentials, app).listen(2055)) //, {'pingTimeout': 25000}
function CurrentTimeStamp() {
    return new Date().toISOString().replace(/T/, " ").replace(/\..+/, "")
}

DbConnect()

function DbConnect() {
    //this is source code for connection
    let MongoClient = require("mongodb").MongoClient
    MongoClient.connect(
        mongoURL,
        {
            // auto_reconnect: true,
            useNewUrlParser: true,
            useUnifiedTopology: true,
        },
        function (err, dbconnection) {
            // if (err) throw err;
            if (err) {
                console.log(err)
            }
            //   console.log('mongoDb connected!!');

            var collection = dbconnection.db(DB_collecation)
            MongoDb.liveuser = collection.collection("liveuser")
            MongoDb.liveuser_audio = collection.collection("liveuser_audio") ////////// new
            MongoDb.user = collection.collection("user")
            MongoDb.history = collection.collection("history")
            MongoDb.history_audio = collection.collection("history_audio") ////////// new
            MongoDb.host_history = collection.collection("host_history")
            MongoDb.friend = collection.collection("friend")
            MongoDb.Appsecret = collection.collection("app_secret")
            MongoDb.ice_server = collection.collection("ice_server")
            MongoDb.payment_history = collection.collection("payment_history")
            MongoDb.fake_video = collection.collection("fake_video")
            MongoDb.coin = collection.collection("coin")
            MongoDb.agent = collection.collection("agent")
            MongoDb.location = collection.collection("location")
            MongoDb.version = collection.collection("version")
            MongoDb.user_masters = collection.collection("user_masters")
            MongoDb.app_user_status = collection.collection("app_user_status")
            MongoDb.black_list = collection.collection("black_list")
            MongoDb.package = collection.collection("package")
            MongoDb.coin_history = collection.collection("coin_history")
            MongoDb.report_user = collection.collection("report_user")

            dbconnection.on("close", function () {
                console.log("Close + ")
                // dbconnection.close();
                let command = "service mongod status || service mongod restart"
                cmd.get(command, function (err, resdata, stderr) {
                    if (!err) {
                        console.log(resdata)
                        DbConnect()
                    }
                })
            })
            dbconnection.on("connected", function () {
                console.log("connected")
            })
        }
    )
}

async function CallAPI() {
    console.log("Calling")
    https
        .get("https://www.smsgateway.center/VoiceApi/rest/send?" + "userId=rkbadarukhiya&password=testT123#&audioType=library&" + "sendMethod=simpleVoice&mobile=918867220155, 919537451054&duplicateCheck=true&" + "libraryId=8514378074225594271&reDial=2&redialInterval=5&format=json", (resp) => {
            let data
            // A chunk of data has been recieved.
            resp.on("data", (chunk) => {
                data += chunk
            })

            // The whole response has been received. Print out the result.
            resp.on("end", () => {
                console.log(JSON.parse(data).explanation)
            })
        })
        .on("error", (err) => {
            console.log("Error: " + err.message)
        })
}

async function ensureDirectoryExistence(filePathArr, callbackPath) {
    for (var i = 0; i < filePathArr.length; i++) {
        let myPromise = new Promise(function (resolve, reject) {
            resolve(fs.existsSync(filePathArr[i]))
        })
        let result = await myPromise
        if (result === true) {
            return callbackPath(filePathArr[i])
        } else if (i === filePathArr.length - 1) {
            return callbackPath(null)
        }
    }

    // filePathArr.forEach(async function (path) {
    //
    //
    //     let myPromise = new Promise(function (resolve, reject) {
    //         resolve(fs.existsSync(path));
    //
    //     });
    //     let result = await myPromise;
    //     if (result === true) {
    //         return callbackPath(path);
    //     }
    //
    // });

    // callbackPath(null);

    // fs.stat(filePath, callback);
}

var _this = (module.exports = {
    MongoDb,
    fs,
    io,
    app,
    Proj_dir,
    sender,
    gcm,
    cmd,
    FileUpload,
    ensureDirectoryExistence,
    CurrentTimeStamp,
    mailtransporter,
    mailOptions,
})
/*Load route*/
paymentAPI.Payment(_this)
//ClenerAPI.Clean(_this);
VideoAPI.VideoAPI(_this)
