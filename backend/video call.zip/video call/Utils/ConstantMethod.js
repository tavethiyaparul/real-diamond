"use strict"

let _this = this

module.exports.sucess = function GetSucess(result) {
    return '{"code":200,"data":' + result + ',"message":"success."}'
}

module.exports.Invalid = function GetError() {
    return '{"code":400,"data":you broke the internet!,"message":"failed."}'
}

module.exports.Error = function GetError(result) {
    return '{"code":204,"data":' + result + ',"message":"failed."}'
}
module.exports.CheckHeader = function (request, constant, callback) {
    if (request.headers.app_secret) {
        constant.MongoDb.Appsecret.findOne({ _id: request.headers.app_secret }, function (err, res) {
            if (!err && res !== null) {
                callback(true)
            } else {
                callback(null)
            }
        })
    } else {
        callback(null)
    }
}

module.exports.TickUpdate = function (data, constant, socket) {
    constant.ensureDirectoryExistence([constant.Proj_dir + "/Resource/ChatFile/" + data.userId + "_" + data.OtherUserId, constant.Proj_dir + "/Resource/ChatFile/" + data.OtherUserId + "_" + data.userId], function (path) {
        if (path == null) {
            return
        }
        let command = constant.Proj_dir + "/shell_script/replace_shell.sh -f=" + data.uniqueID + ' -rf=\\"tickType\\":[0-9]\\\\ -r=\\"tickType\\":' + data.tickType + " -fi=" + path + "/chat.json"
        constant.cmd.get(command, function (err, resdata, stderr) {
            if (!err) {
                constant.MongoDb.liveuser.findOne({ _id: data.OtherUserId }, function (err, res) {
                    if (!err && res != null) {
                        //
                        delete data["eventName"]
                        // data["userId"]=data.OtherUserId;
                        // data['timestamp'] = constant.CurrentTimeStamp();
                        constant.io.to(res.payload.SocketId).emit("VideoClient", {
                            eventName: "TickUpdate",
                            data,
                        })
                    } else {
                        // console.log(err);

                        constant.MongoDb.user.findOne({ _id: data.OtherUserId }, function (err, res) {
                            if (res != null) {
                                // var msg = {data: data};
                                let message = new constant.gcm.Message({
                                    data: { data: data },
                                })
                                if (data.hasOwnProperty("package_name"))
                                    constant.MongoDb.package.findOne({ package_name: res.payload.package_name }, function (err, result) {
                                        if (result != null) {
                                            constant.gcm.Sender(result.gcm_key).sendNoRetry(message, { registrationTokens: [res.payload.token] }, function (err, res) {})
                                        } else {
                                            constant.sender.sendNoRetry(message, { registrationTokens: [res.payload.token] }, function (err, response) {})
                                        }
                                    })
                                else constant.sender.sendNoRetry(message, { registrationTokens: [res.payload.token] }, function (err, response) {})
                            }
                        })
                    }
                })
            }
        })
    })
}

module.exports.WriteFile = function (dataObj, constant, socket) {
    let data = dataObj.data
    data["timestamp"] = constant.CurrentTimeStamp()

    /*Check whether file is exits or not ,if not then create directory*/
    constant.ensureDirectoryExistence([constant.Proj_dir + "/Resource/ChatFile/" + data.userId + "_" + data.OtherUserId, constant.Proj_dir + "/Resource/ChatFile/" + data.OtherUserId + "_" + data.userId], function (path) {
        if (path === null) {
            try {
                constant.fs.mkdirSync((path = constant.Proj_dir + "/Resource/ChatFile/" + data.userId + "_" + data.OtherUserId))
            } catch (error) {
                // your catch block code goes here
            }
        }
        let isFile = data.type

        let isOnline = data.IsOnline
        delete data["IsOnline"]
        data["tickType"] = 1
        if (isFile === 0) {
            let FileName = path + "/chat.json"
            var ws = constant.fs.createWriteStream(FileName, {
                flags: "a",
                encoding: "utf-8",
            })
            ws.write(JSON.stringify(data) + "\n")
        }

        socket.emit("VideoClient", { eventName: "TickUpdatePersonal", data })

        if (isOnline === 1) {
            _this.SendAgain(dataObj, constant, socket)
        } else {
            constant.MongoDb.user.findOne({ _id: data.OtherUserId }, function (err, res) {
                if (res != null) {
                    if (isFile === 0) {
                        let message = new constant.gcm.Message({
                            data: { data: dataObj },
                        })
                        if (data.hasOwnProperty("package_name"))
                            constant.MongoDb.package.findOne({ package_name: res.payload.package_name }, function (err, result) {
                                if (result != null) {
                                    constant.gcm.Sender(result.gcm_key).sendNoRetry(message, { registrationTokens: [res.payload.token] }, function (err, res) {})
                                } else {
                                    constant.sender.sendNoRetry(message, { registrationTokens: [res.payload.token] }, function (err, response) {})
                                }
                            })
                        else constant.sender.sendNoRetry(message, { registrationTokens: [res.payload.token] }, function (err, response) {})
                    } else {
                        // let ImagePath = constant.Proj_dir + "/Resource/TempFile/" + (new Date).getTime() + ".png";
                        let ImagePath = new Date().getTime() + ".png"
                        constant.fs.writeFile(constant.Proj_dir + "/Resource/TempFile/" + ImagePath, dataObj.byte, function (err) {
                            // console.log(ImagePath);
                            if (!err) {
                                delete dataObj["byte"]
                                data["text"] = ImagePath
                                let message = new constant.gcm.Message({
                                    data: { data: dataObj },
                                })
                                if (data.hasOwnProperty("package_name"))
                                    constant.MongoDb.package.findOne({ package_name: res.payload.package_name }, function (err, result) {
                                        if (result != null) {
                                            constant.gcm.Sender(result.gcm_key).sendNoRetry(message, { registrationTokens: [res.payload.token] }, function (err, res) {})
                                        } else {
                                            constant.sender.sendNoRetry(message, { registrationTokens: [res.payload.token] }, function (err, response) {})
                                        }
                                    })
                                else constant.sender.sendNoRetry(message, { registrationTokens: [res.payload.token] }, function (err, response) {})
                            }
                        })
                    }
                }
            })
        }
    })
}
module.exports.SendAgain = function (dataObj, constant, socket) {
    let data = dataObj.data
    dataObj["eventName"] = "Chatting"
    constant.MongoDb.liveuser.findOne({ _id: data.OtherUserId }, function (err, res) {
        if (!err && res != null) {
            constant.io.to(res.payload.SocketId).emit("VideoClient", dataObj)
        } else {
            // socket.broadcast.emit('VideoClient',
            //     {eventName: "IsOnline", OtherUserId: data.OtherUserId, status: 0});

            constant.MongoDb.user.findOne({ _id: data.OtherUserId }, function (err, res) {
                if (res != null) {
                    // var msg = {};
                    let message = new constant.gcm.Message({
                        data: { data: dataObj },
                    })
                    if (data.hasOwnProperty("package_name"))
                        constant.MongoDb.package.findOne({ package_name: res.payload.package_name }, function (err, result) {
                            if (result != null) {
                                constant.gcm.Sender(result.gcm_key).sendNoRetry(message, { registrationTokens: [res.payload.token] }, function (err, res) {})
                            } else {
                                constant.sender.sendNoRetry(message, { registrationTokens: [res.payload.token] }, function (err, response) {})
                            }
                        })
                    else constant.sender.sendNoRetry(message, { registrationTokens: [res.payload.token] }, function (err, response) {})
                }
            })
        }
    })
}
module.exports.UpdateReceiverTick = function (dataObj, constant, socket) {
    let data = dataObj.data
    constant.MongoDb.liveuser.findOne({ _id: data.userId }, function (err, res) {
        if (!err && res != null) {
            constant.io.to(res.payload.SocketId).emit("VideoClient", dataObj)
        } else {
            constant.MongoDb.user.findOne({ _id: data.userId }, function (err, res) {
                if (res != null) {
                    let message = new constant.gcm.Message({
                        data: { data: dataObj },
                    })
                    if (data.hasOwnProperty("package_name"))
                        constant.MongoDb.package.findOne({ package_name: res.payload.package_name }, function (err, result) {
                            if (result != null) {
                                constant.gcm.Sender(result.gcm_key).sendNoRetry(message, { registrationTokens: [res.payload.token] }, function (err, res) {})
                            } else {
                                constant.sender.sendNoRetry(message, { registrationTokens: [res.payload.token] }, function (err, response) {})
                            }
                        })
                    else constant.sender.sendNoRetry(message, { registrationTokens: [res.payload.token] }, function (err, response) {})
                }
            })
        }
    })
}
module.exports.userTyping = function (dataObj, constant, socket) {
    let data = dataObj.data
    if (data.IsOnline === 1) {
        constant.MongoDb.liveuser.findOne({ _id: data.OtherUserId }, function (err, res) {
            if (!err && res != null) {
                constant.io.to(res.payload.SocketId).emit("VideoClient", dataObj)
            }
        })
    }
}
