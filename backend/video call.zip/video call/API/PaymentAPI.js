"use strict";
let ConstantMethod = require('../Utils/ConstantMethod');


var _this = module.exports = {


    Payment: function (constant) {

        constant.app.post('/payment', constant.FileUpload.single('image'), function (request, response) {
            let Data = request.body;
            if (Data.length > 1e6) {
                // FLOOD ATTACK OR FAULTY CLIENT, NUKE REQUEST
                response.end(ConstantMethod.Error("FLOOD ATTACK OR FAULTY CLIENT, NUKE REQUEST."));
                request.connection.destroy();
            } else {
                ConstantMethod.CheckHeader(request, constant, function (isValideHeader) {
                    if (isValideHeader) {
                        switch (Data.eventName) {
                            case "deductCoin":
                                constant.MongoDb.user.findOne(
                                    {_id: Data.id}
                                    , function (err, res) {
                                        if (!err && res != null) {
                                            let NeedDeductCoin = res.payload.Coin;
                                            if (NeedDeductCoin >= Data.deductCoin) {
                                                NeedDeductCoin = Data.deductCoin;
                                                constant.MongoDb.user.updateOne(
                                                    {_id: Data.id},
                                                    {$inc: {"payload.Coin": -NeedDeductCoin}}, {upsert: true}
                                                    , function (err, result) {
                                                        response.end(ConstantMethod.sucess(JSON.stringify({RemainCoin: res.payload.Coin - NeedDeductCoin})));

                                                    })
                                            } else {
                                                response.status(500).send(ConstantMethod.Error(err));
                                            }

                                        }

                                    });
                                break;
                           	
								
								
								
								
								
								
                            case "PurchaseCoin":
                                
                                var txnId;
                                var status;

                                if(Data.txnId!=null)
                                	txnId=Data.txnId;
                                if(Data.status!=null)
                                	status=Data.status;

								if(Data.purchase_token!=null && Data.method=="InApp")// InApp Entry
								{	
									if(Data.productId!=null)
									{
												  //response.end(ConstantMethod.sucess('"already registered."'));
												  const { exec } = require('child_process');
											   
												
												  exec('curl -q \'http://piks.in/gapi/verify.php?token='+Data.purchase_token+'&package_name='+Data.package_name+'&product_id='+Data.productId+'\'', (err, stdout, stderr) => {
														//response.end(ConstantMethod.Error("dfsdfdsf"+stdout+"--"+Data.purchase_token));
												  if (err) {
													//some err occurred
													//console.error(err)
													//response.end(ConstantMethod.sucess('"curl Error."'));
													response.status(500).send(ConstantMethod.Error(err));
												  } else {
												   // the *entire* stdout and stderr (buffered)
												   
												  // response.end(stdout);
													//var verify=JSON.parse(stdout);
													//response.end(verify.purchaseState);
													if(stdout==1)
													{
														// Existning Logic With Token
														//response.end(stdout);
														constant.MongoDb.payment_history.updateOne(
															{_id: Data.id},
															{
																$push: {
																	'trans_': {
																		$each: [
																			{
																				"method": Data.method,
																				"coin": Data.coin,
																				"amount": Data.amount,
																				"purchase_token": Data.purchase_token,
																				"txnId": txnId,
																				"status": status,
																				"package_name": Data.package_name,
																				"version": Data.version,
																				"created_at": constant.CurrentTimeStamp()

																			}
																		]

																	}
																}
															}
															, {upsert: true}

															, function (err, res) {
																if (!err && res != null) {


																	constant.MongoDb.user.updateOne(
																		{_id: Data.id}, {$inc: {"payload.Coin": Data.coin}}, {upsert: true}
																		, function (err, res) {
																			constant.MongoDb.user.findOne(
																				{_id: Data.id}
																				, function (err, res) {
																					if (res != null) {
																						response.end(ConstantMethod.sucess(JSON.stringify(res.payload)));
																					} else {
																						response.status(500).send(ConstantMethod.Error(err));
																					}
																				});
																		});

																} else {
																	response.status(500).send(ConstantMethod.Error(err));
																}

															});
													}
													else{
														//response.end(ConstantMethod.sucess('"curl null."'));
														response.status(500).send(ConstantMethod.Error(err));
													}
													
													
												   //response.end(ConstantMethod.sucess(stderr));
												  }
												});
									}
									else									
									{
												constant.MongoDb.coin.find({Charge:Data.amount}).toArray(function (err, res) {
													if (res != null) {
														//response.end(ConstantMethod.sucess(JSON.stringify(res[0]._id)));
														 //response.end(ConstantMethod.sucess('"already registered."'));
															  const { exec } = require('child_process');
														   
															
															  exec('curl -q \'http://piks.in/gapi/verify.php?token='+Data.purchase_token+'&package_name='+Data.package_name+'&product_id='+res[0]._id+'\'', (err, stdout, stderr) => {
																	//response.end(ConstantMethod.Error("dfsdfdsf"+stdout+"--"+Data.purchase_token));
															  if (err) {
																//some err occurred
																//console.error(err)
																//response.end(ConstantMethod.sucess('"curl Error."'));
																response.status(500).send(ConstantMethod.Error(err));
															  } else {
															   // the *entire* stdout and stderr (buffered)
															   
															  // response.end(stdout);
																//var verify=JSON.parse(stdout);
																//response.end(verify.purchaseState);
																if(stdout==1)
																{
																	// Existning Logic With Token
																	//response.end(stdout);
																	constant.MongoDb.payment_history.updateOne(
																		{_id: Data.id},
																		{
																			$push: {
																				'trans_': {
																					$each: [
																						{
																							"method": Data.method,
																							"coin": Data.coin,
																							"amount": Data.amount,
																							"purchase_token": Data.purchase_token,
																							"txnId": txnId,
																							"status": status,
																							"package_name": Data.package_name,
																							"version": Data.version,
																							"created_at": constant.CurrentTimeStamp()

																						}
																					]

																				}
																			}
																		}
																		, {upsert: true}

																		, function (err, res) {
																			if (!err && res != null) {


																				constant.MongoDb.user.updateOne(
																					{_id: Data.id}, {$inc: {"payload.Coin": Data.coin}}, {upsert: true}
																					, function (err, res) {
																						constant.MongoDb.user.findOne(
																							{_id: Data.id}
																							, function (err, res) {
																								if (res != null) {
																									response.end(ConstantMethod.sucess(JSON.stringify(res.payload)));
																								} else {
																									response.status(500).send(ConstantMethod.Error(err));
																								}
																							});
																					});

																			} else {
																				response.status(500).send(ConstantMethod.Error(err));
																			}

																		});
																}
																else{
																	//response.end(ConstantMethod.sucess('"curl null."'));
																	response.status(500).send(ConstantMethod.Error(err));
																}
																
																
															   //response.end(ConstantMethod.sucess(stderr));
															  }
															});
														
													} else {
														response.status(500).send(ConstantMethod.Error(err));
													}
												});	
									}
									
								}
								else // Paytm Entry
								{
									//console.log("dfsdfdsf"+"--"+Data.purchase_token);
										//response.end(ConstantMethod.Error("dfsdfdsf"+"--"+Data.purchase_token));
									if(Data.version!=null && Data.package_name!=null && Data.method!="InApp")// Old Version Null Manage 
									{
										//console.log("payment_history"+"--"+Data.purchase_token);
										//response.end(ConstantMethod.Error("payment_history"+"--"+Data.purchase_token));
										constant.MongoDb.payment_history.updateOne(
											{_id: Data.id},
											{
												$push: {
													'trans_': {
														$each: [
															{
																"method": Data.method,
																"coin": Data.coin,
																"amount": Data.amount,
																"purchase_token": Data.purchase_token,
																"txnId": txnId,
																"status": status,
																"package_name": Data.package_name,
																"version": Data.version,
																"created_at": constant.CurrentTimeStamp()

															}
														]

													}
												}
											}
											, {upsert: true}

											, function (err, res) {
												if (!err && res != null) {


													constant.MongoDb.user.updateOne(
														{_id: Data.id}, {$inc: {"payload.Coin": Data.coin}}, {upsert: true}
														, function (err, res) {
															constant.MongoDb.user.findOne(
																{_id: Data.id}
																, function (err, res) {
																	if (res != null) {
																		response.end(ConstantMethod.sucess(JSON.stringify(res.payload)));
																	} else {
																		response.status(500).send(ConstantMethod.Error(err));
																	}
																});
														});

												} else {
													response.status(500).send(ConstantMethod.Error(err));
												}

											});
									}
									else
									{
										response.status(500).send(ConstantMethod.Error("Fail Payment"));
									}	
										
								}

                                break;
								
								
								
								
								
								
								
								
								
								
							
                            case "coin":
                                constant.MongoDb.coin.find({enable:"1"}).sort( { Coin : 1 }).toArray(function (err, res) {
                                    if (res != null) {
                                        response.end(ConstantMethod.sucess(JSON.stringify(res)));
                                    } else {
                                        response.status(500).send(ConstantMethod.Error(err));
                                    }
                                });
                                break;

                            case "trans_history":
                               
                                 constant.MongoDb.payment_history.aggregate([
                                        {$match: {_id: Data.user_id}},
                                        {$unwind: '$trans_'},
                                        {$sort: {'trans_.created_at': -1}},
                                        {$skip: Data.skip},
                                        {$limit: Data.limit}
                                    ]).toArray(function (err, res) {
                                        if (!err && res != null && res.length > 0)
                                            response.end(ConstantMethod.sucess(JSON.stringify(res)));
                                        else
                                            response.status(500).send(ConstantMethod.Error(err));


                                    });


                            break;    


                            default:
                                response.status(500).send(ConstantMethod.Invalid());
                                break;
                        }
                    } else {
                        response.end(ConstantMethod.Error("Header is missing!!"));
                    }
                })
            }
        });
    }
};