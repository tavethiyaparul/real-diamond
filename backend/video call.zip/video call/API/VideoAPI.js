"use strict"
let ConstantMethod = require("../Utils/ConstantMethod")
let checksum_lib = require("../Checksum/checksum")
const { google } = require("googleapis")

var _this = (module.exports = {
    VideoAPI: function (constant) {
        constant.app.post("/user", constant.FileUpload.single("image"), function (request, response) {
            // response.writeHead(200, {"Content-Type": "application/json"});
            // console.log("Headers", request.headers.app_secret)
            // console.log("request", request)

            let Data = request.body
            if (Data.eventName === "CheckKey") {
                //console.log(Data);
                response.status(500).send(ConstantMethod.Error(Data))
                return
            }
            if (Data.length > 1e6) {
                // FLOOD ATTACK OR FAULTY CLIENT, NUKE REQUEST
                response.end(ConstantMethod.Error("FLOOD ATTACK OR FAULTY CLIENT, NUKE REQUEST."))
                request.connection.destroy()
            } else {
                ConstantMethod.CheckHeader(request, constant, function (isValideHeader) {
                    if (isValideHeader) {
                        switch (Data.eventName) {
                            case "RandomMsg":
                                constant.MongoDb.liveuser
                                    .find({ _id: { $ne: Data.id }, "payload.userObj": { $ne: null }, "payload.status": { $in: [1, 2, 3] } })
                                    .limit(25)
                                    .toArray(function (err, res) {
                                        //console.log(JSON.stringify(data));
                                        //console.log("----Random MSG LIST---------------------- "+res);
                                        //console.log(JSON.stringify(res));

                                        response.end(ConstantMethod.sucess(JSON.stringify(res)))
                                    })
                                break

                            case "blockList":
                                constant.MongoDb.report_user.find({ report_by: Data.id }).toArray(function (err, res) {
                                    if (!err && res != null) {
                                        response.end(ConstantMethod.sucess(JSON.stringify(res)))
                                    } else {
                                        response.status(500).send(ConstantMethod.Error(err))
                                    }
                                })
                                break

                            case "unblock":
                                if (Data.report_by != null) {
                                    constant.MongoDb.report_user.deleteOne({ report_by: Data.report_by, report_to: Data.report_to }, function (err, res) {
                                        if (!err) {
                                            //console.log("report_user.deleteOne "+Data.id);
                                            response.end(ConstantMethod.sucess('"Unblock sucessfully"'))
                                        } else {
                                            response.status(500).send(ConstantMethod.Invalid())
                                        }
                                    })
                                } else {
                                    constant.MongoDb.report_user.deleteOne({ report_to: Data.id }, function (err, res) {
                                        if (!err) {
                                            // console.log("report_user.deleteOne "+Data.id);
                                            response.end(ConstantMethod.sucess('"Unblock sucessfully"'))
                                        } else {
                                            response.status(500).send(ConstantMethod.Invalid())
                                        }
                                    })
                                }

                                break

                            case "report":
                                constant.MongoDb.report_user.find({ report_by: Data.reportBy, report_to: Data.reportTo }).toArray(function (err, res) {
                                    if (!err && res != null && res.length > 0) {
                                        //console.log("not null")
                                        response.end(ConstantMethod.sucess('"User report sucessfully"'))
                                    } else if (!err) {
                                        //console.log("else")
                                        constant.MongoDb.report_user.insertOne(
                                            {
                                                report_by: Data.reportBy,
                                                report_to: Data.reportTo,
                                                reason: Data.reason,
                                                gender: Data.gender,
                                                profile: Data.profile,
                                                name: Data.name,
                                                datetime: Data.datetime,
                                            },
                                            function (err) {
                                                if (!err) {
                                                    response.end(ConstantMethod.sucess('"User report sucessfully"'))
                                                } else {
                                                    response.status(500).send(ConstantMethod.Invalid())
                                                }
                                            }
                                        )
                                    } else response.end(ConstantMethod.sucess('"User report sucessfully"'))
                                })
                                break

                            case "SendPush":
                                constant.MongoDb.user.findOne(
                                    { _id: Data.userId },

                                    function (err, res) {
                                        if (res != null) {
                                            // let msg = {msg: "As per your request we removed " + res.payload.Name};
                                            let message = new constant.gcm.Message({
                                                data: { payload: { msg: "As per your request we removed " + res.payload.Name } },
                                            })
                                            constant.MongoDb.package.findOne({ _id: request.headers.app_secret }, function (err, result) {
                                                if (result != null) {
                                                    constant.gcm.Sender(result.gcm_key).sendNoRetry(message, { registrationTokens: [res.payload.token] }, function (err, res) {
                                                        response.end(ConstantMethod.sucess(res))
                                                    })
                                                } else {
                                                    constant.sender.sendNoRetry(message, { registrationTokens: [res.payload.token] }, function (err, res) {
                                                        response.end(ConstantMethod.sucess(res))
                                                    })
                                                }
                                            })
                                        } else {
                                            response.status(500).send(ConstantMethod.Error(err))
                                        }
                                    }
                                )

                                break
                            case "ReportUser":
                                constant.MongoDb.user.findOne(
                                    { _id: Data.userId },

                                    function (err, res) {
                                        if (res != null) {
                                            constant.mailOptions.text = JSON.stringify(res.payload)
                                            constant.MongoDb.user.findOne(
                                                { _id: Data.OtherUserId },

                                                function (err, res) {
                                                    if (res != null) {
                                                        constant.mailOptions.text += "\n------\nReport:" + Data.Report + "\n-------\nBlocked to:" + JSON.stringify(res.payload)

                                                        constant.mailtransporter.sendMail(constant.mailOptions, function (err, info) {
                                                            if (!err) {
                                                                response.end(ConstantMethod.sucess())
                                                            } else {
                                                                response.status(500).send(ConstantMethod.Error(err))
                                                            }
                                                        })
                                                    } else {
                                                        response.status(500).send(ConstantMethod.Error(err))
                                                    }
                                                }
                                            )
                                        } else {
                                            response.status(500).send(ConstantMethod.Error(err))
                                        }
                                    }
                                )
                                break
                            case "IceServer":
                                constant.MongoDb.ice_server.findOne({}, function (err, res) {
                                    if (!err && res != null) {
                                        response.end(ConstantMethod.sucess(JSON.stringify(res)))
                                    } else {
                                        response.status(500).send(ConstantMethod.Error(err))
                                    }
                                })

                                break
                            case "ValidUser":
                                delete Data["eventName"]
                                constant.MongoDb.user.findOne(
                                    { _id: Data.userId, "payload.token": Data.token },

                                    function (err, res) {
                                        if (res != null) {
                                            constant.MongoDb.black_list.findOne({ _id: Data.userId }, function (err, resm) {
                                                if (resm != null) {
                                                    response.status(500).send(ConstantMethod.Error(err))
                                                } else {
                                                    if (!res.payload.hasOwnProperty("FreeCoin")) {
                                                        res.payload.FreeCoin = 0
                                                        res.payload.Coin = 0
                                                    }

                                                    if (Data.hasOwnProperty("package_name")) {
                                                        //console.log("VVVVVVV"+JSON.stringify(Data));
                                                        if (!res.payload.hasOwnProperty("app_version")) res.payload.app_version = Data.app_version
                                                        else res.payload.app_version = Data.app_version

                                                        if (!res.payload.hasOwnProperty("package_name")) res.payload.package_name = Data.package_name
                                                        else res.payload.package_name = Data.package_name
                                                    }

                                                    res.payload.Lastlogin = new Date()
                                                    constant.MongoDb.user.updateOne({ _id: Data.userId }, { $set: res }, { upsert: true }, function (err, result) {
                                                        response.end(ConstantMethod.sucess(JSON.stringify(res.payload)))
                                                    })
                                                }
                                            })
                                        } else {
                                            response.status(500).send(ConstantMethod.Error(err))
                                            // response.end(ConstantMethod.Error(err));
                                        }
                                    }
                                )
                                break
                            case "UserRegistered":
                                delete Data["eventName"]
                                constant.MongoDb.user.findOne({ "payload.userId": Data.userId, "payload.package_name": Data.package_name }, function (err, res) {
                                    if (res != null) {
                                        //update user details
                                        constant.MongoDb.black_list.findOne({ _id: Data.userId }, function (err, resm) {
                                            if (resm != null) {
                                                response.status(500).send(ConstantMethod.Error(err))
                                            } else {
                                                if (!res.payload.hasOwnProperty("FreeCoin")) {
                                                    res.payload.FreeCoin = 0
                                                    res.payload.Coin = 0
                                                }
                                                res.payload.token = Data.token
                                                res.payload.package_name = Data.package_name
                                                res.payload.Lastlogin = new Date()

                                                if (!res.payload.hasOwnProperty("userId")) res.payload.userId = Data.userId
                                                if (!res.payload.hasOwnProperty("Gender")) res.payload.Gender = Data.Gender
                                                else res.payload.Gender = Data.Gender

                                                if (!res.payload.hasOwnProperty("type")) res.payload.type = Data.type
                                                // if (!res.payload.hasOwnProperty("Profile")) res.payload.Profile = Data.Profile
                                                // else res.payload.Profile = Data.Profile

                                                if (!res.payload.hasOwnProperty("app_version")) res.payload.app_version = Data.app_version
                                                else res.payload.app_version = Data.app_version

                                                if (!res.payload.hasOwnProperty("Name")) res.payload.Name = Data.Name
                                                else res.payload.Name = Data.Name

                                                if (!res.payload.hasOwnProperty("purchaseToken")) res.payload.purchaseToken = ""

                                                if (Data.userId == "t3oQ3vaU49ZKubOJHg4luj1TybV2") {
                                                    //console.log("Old "+JSON.stringify(Data));
                                                    //console.log("Old PK "+res.payload.package_name);
                                                }

                                                constant.MongoDb.user.updateOne({ _id: Data.userId, "payload.package_name": Data.package_name }, { $set: res }, { upsert: true }, function (err, result) {
                                                    if (!err) {
                                                        //if(Data.userId=="t3oQ3vaU49ZKubOJHg4luj1TybV2")
                                                        //	console.log("Sucesss UPDATEEEEEEE");
                                                        res.payload.isRegister = 0
                                                        response.end(ConstantMethod.sucess(JSON.stringify(res.payload)))
                                                    } else {
                                                        //if(Data.userId=="t3oQ3vaU49ZKubOJHg4luj1TybV2")
                                                        //	console.log("FAil UPDATEEEEEEE");
                                                        response.status(500).send(ConstantMethod.Error(err))
                                                    }
                                                })
                                            }
                                        })
                                    } else {
                                        //if(Data.userId=="117034206793229085778")
                                        //		console.log("New "+JSON.stringify(Data));

                                        //new user
                                        if (!Data.hasOwnProperty("FreeCoin")) {
                                            Data.FreeCoin = 0
                                            //Data.Coin = 0;

                                            var c_no = Math.floor(Math.random() * Math.floor(3))
                                            if (c_no == 0) Data.Coin = 0
                                            else if (c_no == 1) Data.Coin = 0
                                            else Data.Coin = 0
                                        }
                                        if (Data.package_name != null && Data.package_name == "com.videocall.randomcallapps" && Data.type >= 0) Data.Coin = 10

                                        Data.Lastlogin = new Date()
                                        Data.planExpired = 0
                                        Data.planId = 0
                                        Data.planPurchaseDate = 0
                                        Data.paymentMode = ""
                                        Data.paymentMode = ""
                                        Data.purchaseToken = ""
                                        constant.MongoDb.user.findOneAndUpdate({ _id: Data.userId, "payload.package_name": Data.package_name }, { $set: { payload: Data } }, { returnDocument: "after", upsert: true }, function (err, res) {
                                            if (!err) {
                                                //if(Data.userId=="t3oQ3vaU49ZKubOJHg4luj1TybV2")
                                                //	console.log("Sucesss UPDATEEEEEEE");
                                                Data.isRegister = 1 // new register
                                                response.end(ConstantMethod.sucess(JSON.stringify(Data)))
                                            } else {
                                                //if(Data.userId=="t3oQ3vaU49ZKubOJHg4luj1TybV2")
                                                //	console.log("FAil UPDATEEEEEEE");
                                                response.status(500).send(ConstantMethod.Error(err))
                                            }
                                        })
                                    }
                                })

                                break

                            case "UserNameUpdate":
                                delete Data["eventName"]

                                constant.MongoDb.user.updateOne({ _id: Data.userId, "payload.package_name": Data.package_name }, { $set: { "payload.Name": Data.Name } }, { upsert: false }, function (err, result) {
                                    if (!err) {
                                        response.end(ConstantMethod.sucess(JSON.stringify("Successfully Update.")))
                                    } else {
                                        response.status(500).send(ConstantMethod.Error(err))
                                    }
                                })

                                break

                            case "Subscription":
                                let purchaseDate = new Date().getTime()
                                if (Data.planCancel == 0) {
                                    //planCancel 0
                                    constant.MongoDb.user.findOneAndUpdate({ _id: Data.userId, "payload.package_name": Data.package_name }, { $set: { "payload.planExpired": purchaseDate, "payload.planCancel": 0 } }, { returnDocument: "after", upsert: true }, function (err, result) {
                                        if (!err) {
                                            console.log("--", result)
                                            response.end(ConstantMethod.sucess(JSON.stringify({ planPurchaseDate: result.value.payload.planPurchaseDate, planExpired: result.value.payload.planExpired, paymentMode: result.value.payload.paymentMode, planCancel: result.value.payload.planCancel })))
                                        } else {
                                            response.status(500).send(ConstantMethod.Error(err))
                                        }
                                    })
                                } else {
                                    //new plan

                                    let expire = purchaseDate + 86400000 * Data.Duration

                                    constant.MongoDb.user.findOneAndUpdate({ _id: Data.userId, "payload.package_name": Data.package_name }, { $set: { "payload.planPurchaseDate": purchaseDate, "payload.planId": Data.planId, "payload.planExpired": +expire, "payload.paymentMode": Data.paymentMode, "payload.purchaseToken": Data.purchaseToken } }, { returnDocument: "after", upsert: false }, function (err, result) {
                                        if (!err) {
                                            response.end(ConstantMethod.sucess(JSON.stringify({ planPurchaseDate: purchaseDate, planExpired: expire, paymentMode: Data.paymentMode })))
                                        } else {
                                            response.status(500).send(ConstantMethod.Error(err))
                                        }
                                    })
                                }
                                break

                            case "Verify_user":
                                let creden
                                if (Data.packageName === "com.pandachat.randomvideocall") {
                                    creden = require("/var/www/random_video/public_html/VideoNodeLive/pandachat.json")
                                }
                                google.auth
                                    .getClient({
                                        credentials: creden,
                                        scopes: ["https://www.googleapis.com/auth/androidpublisher"],
                                    })
                                    .then((client) => {
                                        const androidPublisher = google.androidpublisher({
                                            version: "v3",
                                            auth: client,
                                        })

                                        androidPublisher.purchases.subscriptionsv2
                                            .get({
                                                packageName: Data.packageName,
                                                token: Data.token,
                                            })
                                            .then((data) => {
                                                // console.log("resp data",data.data.acknowledgementState,data.data.lineItems[0].productId)
                                                if (data.data.acknowledgementState === "ACKNOWLEDGEMENT_STATE_PENDING") {
                                                    androidPublisher.purchases.subscriptions
                                                        .acknowledge({
                                                            packageName: Data.packageName,
                                                            subscriptionId: data.data.lineItems[0].productId,
                                                            token: Data.token,
                                                        })
                                                        .then((resp) => {
                                                            // console.log("else",res.data)
                                                            response.send(ConstantMethod.sucess(JSON.stringify(data.data)))
                                                        })
                                                        .catch((error) => {
                                                            console.log("error", error)
                                                            res.send(ConstantMethod.Error('"' + error + '"'))
                                                        })
                                                } else {
                                                    response.send(ConstantMethod.sucess(JSON.stringify(data.data)))
                                                }
                                            })
                                            .catch((err) => {
                                                console.error("subscriptions:", err)
                                                response.send(ConstantMethod.Error('"' + err + '"'))
                                            })
                                    })
                                break

                            case "Userdelete":
                                constant.MongoDb.user.deleteOne({ _id: Data.userId, "payload.package_name": Data.package_name }, function (err, res) {
                                    if (!err) {
                                        response.end(ConstantMethod.sucess('"Delete sucessfully"'))
                                    } else {
                                        response.status(500).send(ConstantMethod.Invalid())
                                    }
                                })
                                break

                            case "Checksum":
                                var paytmParams = {}
                                /* put checksum parameters in Object */
                                paytmParams["CUST_ID"] = Data["CUST_ID"]
                                paytmParams["CHANNEL_ID"] = Data["CHANNEL_ID"]
                                paytmParams["MID"] = Data["MID"]
                                paytmParams["ORDER_ID"] = Data["ORDER_ID"]
                                paytmParams["TXN_AMOUNT"] = Data["TXN_AMOUNT"]
                                paytmParams["WEBSITE"] = Data["WEBSITE"]
                                paytmParams["INDUSTRY_TYPE_ID"] = Data["INDUSTRY_TYPE_ID"]
                                paytmParams["CALLBACK_URL"] = Data["CALLBACK_URL"]
                                checksum_lib.genchecksum(paytmParams, Data["MKEY"], function (err, checksum) {
                                    // console.log(checksum);
                                    if (checksum != null) response.end(ConstantMethod.sucess(JSON.stringify(checksum)))
                                    else response.status(500).send(ConstantMethod.Error(err))
                                })
                                break
                            case "UpdateToken":
                                delete Data["eventName"]
                                constant.MongoDb.user.updateOne({ _id: Data.userId }, { $set: { "payload.token": Data.token } }, function (err, res) {
                                    if (!err) {
                                        response.end(ConstantMethod.sucess(JSON.stringify(Data)))
                                    } else {
                                        response.status(500).send(ConstantMethod.Error(err))
                                    }
                                })
                                break
                            case "AllAgent":
                                constant.MongoDb.location
                                    .aggregate([
                                        // {$match: {}},
                                        {
                                            $lookup: {
                                                from: "agent",
                                                localField: "_id",
                                                foreignField: "l_id",
                                                as: "agentList",
                                            },
                                        },
                                        { $unwind: "$agentList" },
                                        {
                                            $lookup: {
                                                from: "liveuser",
                                                localField: "agentList._id",
                                                foreignField: "_id",
                                                as: "live",
                                            },
                                        },
                                        {
                                            $project: {
                                                isOnline: { $cond: [{ $eq: ["$live", []] }, 0, 1] },
                                                agentList: 1,
                                                l_name: 1,
                                            },
                                        },
                                        {
                                            $group: {
                                                _id: { _id: "$_id", l_name: "$l_name" },
                                                agentList: {
                                                    $push: {
                                                        Name: "$agentList.Name",
                                                        Gender: "$agentList.Gender",
                                                        l_id: "$agentList.l_id",
                                                        IsOnline: "$isOnline",
                                                        coin: "$agentList.coin",
                                                        like: "$agentList.like",
                                                        Profile: "$agentList.Profile",
                                                    },
                                                },
                                            },
                                        },
                                        { $replaceRoot: { newRoot: { $mergeObjects: ["$_id", { agentList: "$agentList" }] } } },
                                    ])
                                    .toArray(function (err, res) {
                                        if (!err && res != null && res.length > 0) {
                                            response.end(ConstantMethod.sucess(JSON.stringify(res)))
                                        } else {
                                            response.status(500).send(ConstantMethod.Error(err))
                                        }
                                    })
                                break
                            case "Agent":
                                constant.MongoDb.agent
                                    .aggregate([
                                        { $match: {} },
                                        {
                                            $lookup: {
                                                from: "liveuser",
                                                localField: "_id",
                                                foreignField: "_id",
                                                as: "live",
                                            },
                                        },
                                        {
                                            $project: {
                                                isOnline: { $cond: [{ $eq: ["$live", []] }, 0, 1] },
                                                _id: 1,
                                                Name: 1,
                                                Gender: 1,
                                                cn: 1,
                                                live: 1,
                                                Profile: 1,
                                                coin: 1,
                                            },
                                        },
                                    ])
                                    .toArray(function (err, res) {
                                        if (!err && res != null && res.length > 0) {
                                            response.end(ConstantMethod.sucess(JSON.stringify(res)))
                                        } else {
                                            response.status(500).send(ConstantMethod.Error(err))
                                        }
                                    })
                                break
                            case "UpdatePhoto":
                                delete Data["eventName"]
                                constant.MongoDb.user.updateOne({ _id: Data.userId }, { $set: { "payload.Profile": request.file.filename } }, { upsert: true }, function (err, res) {
                                    if (!err) {
                                        response.end(ConstantMethod.sucess(JSON.stringify(Data)))
                                    } else {
                                        response.status(500).send(ConstantMethod.Error(err))
                                    }
                                })

                                break
                            case "UpdateProfile":
                                delete Data["eventName"]
                                constant.MongoDb.user.updateOne({ _id: Data.userId }, { $set: { "payload.Name": Data.Name } }, { upsert: true }, function (err, res) {
                                    if (!err) {
                                        constant.MongoDb.user_masters.updateOne({ uid: Data.userId }, { $set: { first_name: Data.Name, last_name: "" } }, { upsert: true }, function (err, res) {
                                            if (!err) {
                                            } else {
                                            }
                                        })

                                        response.end(ConstantMethod.sucess(JSON.stringify(Data)))
                                    } else {
                                        response.status(500).send(ConstantMethod.Error(err))
                                    }
                                })

                                break

                            case "host_history":
                                constant.MongoDb.host_history.insert(
                                    {
                                        id: Data.id,
                                        duration: Data.duration,
                                        callType: Data.callType,
                                        masterId: Data.masterId,
                                        uId: Data.uId,
                                        callerId: Data.callerId,
                                        dateTime: new Date(),
                                    },
                                    function (err) {
                                        if (!err) {
                                            response.end(ConstantMethod.sucess('"Record added."'))
                                        } else {
                                            response.status(500).send(ConstantMethod.Error(err))
                                        }
                                    }
                                )

                                break

                            case "host_history_update":
                                constant.MongoDb.host_history.updateOne(
                                    { id: Data.id },
                                    {
                                        $set: {
                                            duration: Data.duration,
                                        },
                                    },
                                    { upsert: false },
                                    function (err) {
                                        if (!err) {
                                            response.end(ConstantMethod.sucess('"Record Updated."'))
                                        } else {
                                            response.status(500).send(ConstantMethod.Error(err))
                                        }
                                    }
                                )

                                break

                            case "History":
                                delete Data["eventName"]
                                constant.MongoDb.history
                                    .aggregate([
                                        { $match: { _id: Data.id } },
                                        { $unwind: "$payload.caller" },
                                        {
                                            $lookup: {
                                                from: "user",
                                                localField: "payload.caller.id",
                                                foreignField: "_id",
                                                as: "UserHistory",
                                            },
                                        },
                                        { $unwind: "$UserHistory" },
                                        {
                                            $lookup: {
                                                from: "friend",
                                                localField: "_id",
                                                foreignField: "_id",
                                                as: "Friend",
                                            },
                                        },
                                        { $unwind: { path: "$Friend", preserveNullAndEmptyArrays: true } },

                                        {
                                            $project: {
                                                UserHistory: 1,
                                                payload: 1,
                                                ReqStatus: {
                                                    $cond: [
                                                        { $gt: ["$Friend", null] },
                                                        {
                                                            $cond: [
                                                                { $in: ["$UserHistory._id", "$Friend.payload.pending"] },
                                                                0,
                                                                {
                                                                    $cond: [
                                                                        { $in: ["$UserHistory._id", "$Friend.payload.rejected"] },
                                                                        1,
                                                                        {
                                                                            $cond: [
                                                                                { $in: ["$UserHistory._id", "$Friend.payload.sent"] },
                                                                                2,
                                                                                {
                                                                                    $cond: [
                                                                                        { $in: ["$UserHistory._id", "$Friend.payload.rejectedByOther"] },
                                                                                        3,
                                                                                        {
                                                                                            $cond: [{ $in: ["$UserHistory._id", "$Friend.payload.accepted"] }, 4, -1],
                                                                                        },
                                                                                    ],
                                                                                },
                                                                            ],
                                                                        },
                                                                    ],
                                                                },
                                                            ],
                                                        },
                                                        -1,
                                                    ],
                                                },
                                            },
                                        },

                                        { $replaceRoot: { newRoot: { $mergeObjects: ["$payload.caller", "$UserHistory.payload", { ReqStatus: "$ReqStatus" }] } } },
                                        { $sort: { date: -1 } },
                                        { $limit: Data.limit },
                                        { $skip: Data.skip },
                                    ])
                                    .toArray(function (err, res) {
                                        if (!err && res != null) {
                                            response.end(ConstantMethod.sucess(JSON.stringify(res)))
                                        } else {
                                            response.status(500).send(ConstantMethod.Error(err))
                                        }
                                    })

                                break

                            case "AudioHistory":
                                delete Data["eventName"]
                                constant.MongoDb.history_audio
                                    .aggregate([
                                        { $match: { _id: Data.id } },
                                        { $unwind: "$payload.caller" },
                                        {
                                            $lookup: {
                                                from: "user",
                                                localField: "payload.caller.id",
                                                foreignField: "_id",
                                                as: "UserHistory",
                                            },
                                        },
                                        { $unwind: "$UserHistory" },
                                        {
                                            $lookup: {
                                                from: "friend",
                                                localField: "_id",
                                                foreignField: "_id",
                                                as: "Friend",
                                            },
                                        },
                                        { $unwind: { path: "$Friend", preserveNullAndEmptyArrays: true } },

                                        {
                                            $project: {
                                                UserHistory: 1,
                                                payload: 1,
                                                ReqStatus: {
                                                    $cond: [
                                                        { $gt: ["$Friend", null] },
                                                        {
                                                            $cond: [
                                                                { $in: ["$UserHistory._id", "$Friend.payload.pending"] },
                                                                0,
                                                                {
                                                                    $cond: [
                                                                        { $in: ["$UserHistory._id", "$Friend.payload.rejected"] },
                                                                        1,
                                                                        {
                                                                            $cond: [
                                                                                { $in: ["$UserHistory._id", "$Friend.payload.sent"] },
                                                                                2,
                                                                                {
                                                                                    $cond: [
                                                                                        { $in: ["$UserHistory._id", "$Friend.payload.rejectedByOther"] },
                                                                                        3,
                                                                                        {
                                                                                            $cond: [{ $in: ["$UserHistory._id", "$Friend.payload.accepted"] }, 4, -1],
                                                                                        },
                                                                                    ],
                                                                                },
                                                                            ],
                                                                        },
                                                                    ],
                                                                },
                                                            ],
                                                        },
                                                        -1,
                                                    ],
                                                },
                                            },
                                        },

                                        { $replaceRoot: { newRoot: { $mergeObjects: ["$payload.caller", "$UserHistory.payload", { ReqStatus: "$ReqStatus" }] } } },
                                        { $sort: { date: -1 } },
                                        { $limit: Data.limit },
                                        { $skip: Data.skip },
                                    ])
                                    .toArray(function (err, res) {
                                        if (!err && res != null) {
                                            response.end(ConstantMethod.sucess(JSON.stringify(res)))
                                        } else {
                                            response.status(500).send(ConstantMethod.Error(err))
                                        }
                                    })

                                break

                            case "RequestSend":
                                _this.MultipleBatch(constant, Data, function (batch) {
                                    if (batch == null) {
                                        response.status(500).send(ConstantMethod.Error(null))
                                    } else
                                        batch.execute(function (err, res) {
                                            if (!err) {
                                                // console.log(err);
                                                response.end(ConstantMethod.sucess(JSON.stringify(res)))
                                            } else {
                                                response.status(500).send(ConstantMethod.Error(err))
                                            }
                                        })
                                })

                                break
                            case "ChatRequest":
                                {
                                    delete Data["eventName"]

                                    constant.MongoDb.user.findOne({ _id: Data.id }, function (err, res) {
                                        if (res != null) {
                                            let _main_coin = res.payload.Coin
                                            if (_main_coin >= Data.deductCoin) {
                                                let batch = constant.MongoDb.user.initializeUnorderedBulkOp({ useLegacyOps: true })

                                                batch.find({ _id: Data.id }).updateOne({
                                                    $inc: { "payload.Coin": -Data.deductCoin },
                                                })
                                                batch.execute(function (err, res) {
                                                    if (!err) {
                                                        batch = constant.MongoDb.friend.initializeUnorderedBulkOp({ useLegacyOps: true })
                                                        batch.find({ _id: Data.id }).updateOne({
                                                            $addToSet: { "payload.accepted": Data.ReqUserId },
                                                            $pull: {
                                                                "payload.sent": Data.ReqUserId,
                                                                "payload.pending": Data.ReqUserId,
                                                                "payload.rejected": Data.ReqUserId,
                                                                "payload.rejectedByOther": Data.ReqUserId,
                                                            },
                                                        })
                                                        batch.find({ _id: Data.ReqUserId }).updateOne({
                                                            $addToSet: { "payload.accepted": Data.id },
                                                            $pull: {
                                                                "payload.sent": Data.id,
                                                                "payload.pending": Data.id,
                                                                "payload.rejected": Data.id,
                                                                "payload.rejectedByOther": Data.id,
                                                            },
                                                        })
                                                        batch.execute(function (err, res) {
                                                            if (!err) {
                                                                constant.MongoDb.user.findOne({ _id: Data.id }, function (err, res) {
                                                                    response.end(ConstantMethod.sucess(JSON.stringify(res.payload)))
                                                                })
                                                            }
                                                        })
                                                    }
                                                })
                                            } else {
                                                response.status(500).send(ConstantMethod.Error("No enough coin."))
                                            }
                                        } else {
                                            response.status(500).send(ConstantMethod.Error("No user found!!"))
                                        }
                                    })
                                }
                                break
                            case "DeleteReq":
                                constant.MongoDb.history.updateOne(
                                    { _id: Data.id },
                                    { $pull: { "payload.caller": { id: Data.OtherUser } } },

                                    { upsert: true },
                                    function (err, res) {
                                        response.end(ConstantMethod.sucess("success."))
                                    }
                                )
                                break
                            case "RequestAccept":
                                {
                                    //console.log("FRD RequestAccept ");
                                    delete Data["eventName"]

                                    let batch = constant.MongoDb.friend.initializeUnorderedBulkOp({ useLegacyOps: true })

                                    batch.find({ _id: Data.id }).updateOne({
                                        $addToSet: { "payload.accepted": Data.ReqUserId },
                                        $pull: { "payload.pending": Data.ReqUserId },
                                    })
                                    batch.find({ _id: Data.ReqUserId }).updateOne({
                                        $addToSet: { "payload.accepted": Data.id },
                                        $pull: { "payload.sent": Data.id },
                                    })

                                    batch.execute(function (err, res) {
                                        if (!err) {
                                            response.end(ConstantMethod.sucess(JSON.stringify(Data)))
                                            constant.MongoDb.user.find({ _id: { $in: [Data.ReqUserId, Data.id] } }).toArray(function (err, res) {
                                                if (res != null && res.length > 0) {
                                                    let token = null
                                                    let username = null
                                                    if (res[0]._id === Data.id) {
                                                        username = res[0].payload.Name
                                                        token = res[1].payload.token
                                                    } else {
                                                        username = res[1].payload.Name
                                                        token = res[0].payload.token
                                                    }

                                                    var msg = { msg: "Your friend request accepted by " + username }
                                                    let message = new constant.gcm.Message({
                                                        data: { msg },
                                                    })
                                                    constant.MongoDb.package.findOne({ _id: request.headers.app_secret }, function (err, result) {
                                                        if (result != null) {
                                                            constant.gcm.Sender(result.gcm_key).sendNoRetry(message, { registrationTokens: [token] }, function (err, res) {
                                                                response.end(ConstantMethod.sucess(res))
                                                            })
                                                        } else {
                                                            constant.sender.sendNoRetry(message, { registrationTokens: [token] }, function (err, response) {})
                                                        }
                                                    })
                                                }
                                            })
                                        } else {
                                            response.status(500).send(ConstantMethod.Error(err))
                                        }
                                    })
                                }
                                break

                            case "RequestReject":
                                delete Data["eventName"]

                                let batch = constant.MongoDb.friend.initializeUnorderedBulkOp({ useLegacyOps: true })

                                batch.find({ _id: Data.id }).updateOne({
                                    $addToSet: { "payload.rejected": Data.ReqUserId },
                                    $pull: { "payload.pending": Data.ReqUserId },
                                })
                                batch.find({ _id: Data.ReqUserId }).updateOne({
                                    $addToSet: { "payload.rejectedByOther": Data.id },
                                    $pull: { "payload.sent": Data.id },
                                })

                                batch.execute(function (err, res) {
                                    if (!err) {
                                        response.end(ConstantMethod.sucess(JSON.stringify(Data)))
                                    } else {
                                        response.status(500).send(ConstantMethod.Error(err))
                                    }
                                })
                                break
                            case "GetRequest":
                                delete Data["eventName"]
                                constant.MongoDb.friend
                                    .aggregate([
                                        { $match: { _id: Data.id } },
                                        { $unwind: "$payload.pending" },
                                        {
                                            $lookup: {
                                                from: "user",
                                                localField: "payload.pending",
                                                foreignField: "_id",
                                                as: "Friend",
                                            },
                                        },
                                        {
                                            $project: {
                                                Friend: 1,
                                            },
                                        },
                                        { $unwind: "$Friend" },

                                        {
                                            $replaceRoot: {
                                                newRoot: "$Friend.payload",
                                            },
                                        },
                                        { $limit: Data.limit },
                                        { $skip: Data.skip },
                                    ])
                                    .toArray(function (err, res) {
                                        if (!err && res != null && res.length > 0) response.end(ConstantMethod.sucess(JSON.stringify(res)))
                                        else response.status(500).send(ConstantMethod.Error(err))
                                    })
                                break
                            case "GetFriend":
                                delete Data["eventName"]
                                constant.MongoDb.friend
                                    .aggregate([
                                        { $match: { _id: Data.id } },
                                        { $unwind: "$payload.accepted" },
                                        {
                                            $lookup: {
                                                from: "user",
                                                localField: "payload.accepted",
                                                foreignField: "_id",
                                                as: "Friend",
                                            },
                                        },
                                        { $unwind: "$Friend" },
                                        {
                                            $project: {
                                                Friend: 1,
                                            },
                                        },
                                        {
                                            $replaceRoot: {
                                                newRoot: "$Friend.payload",
                                            },
                                        },
                                        // {$group: {_id:{id:'$_id'},Friend :{$addToSet:'$Friend.payload'}}},
                                        { $limit: Data.limit },
                                        { $skip: Data.skip },
                                    ])
                                    .toArray(function (err, res) {
                                        if (!err && res != null && res.length > 0) response.end(ConstantMethod.sucess(JSON.stringify(res)))
                                        else response.status(500).send(ConstantMethod.Error(err))
                                    })
                                break
                            case "BlockList":
                                {
                                    constant.MongoDb.friend
                                        .aggregate([
                                            { $match: { _id: Data.id } },
                                            { $unwind: "$payload.block" },
                                            {
                                                $lookup: {
                                                    from: "user",
                                                    localField: "payload.block",
                                                    foreignField: "_id",
                                                    as: "user",
                                                },
                                            },
                                            { $unwind: "$user" },
                                            { $replaceRoot: { newRoot: { $mergeObjects: ["$user.payload"] } } },
                                        ])
                                        .toArray(function (err, res) {
                                            if (!err && res != null) {
                                                response.end(ConstantMethod.sucess(JSON.stringify(res)))
                                            } else response.status(500).send(ConstantMethod.Error("User not existed."))
                                        })
                                }
                                break
                            case "UnBlock":
                                {
                                    let batch = constant.MongoDb.friend.initializeUnorderedBulkOp({ useLegacyOps: true })
                                    delete Data["eventName"]
                                    batch.find({ _id: Data.id }).updateOne({
                                        $pull: { "payload.block": Data.ReqUserId },
                                    })
                                    batch.execute(function (err, result) {
                                        response.end(ConstantMethod.sucess(JSON.stringify(result)))
                                    })
                                }
                                break
                            case "BlockUser":
                                {
                                    delete Data["eventName"]

                                    let batch = constant.MongoDb.friend.initializeUnorderedBulkOp({ useLegacyOps: true })

                                    batch.find({ _id: Data.id }).updateOne({
                                        $pull: { "payload.accepted": Data.ReqUserId },
                                    })
                                    batch.find({ _id: Data.ReqUserId }).updateOne({
                                        $pull: { "payload.accepted": Data.id },
                                    })
                                    batch.find({ _id: Data.id }).updateOne({ $addToSet: { "payload.block": Data.ReqUserId } })

                                    batch.execute(function (err, result) {
                                        if (!err) {
                                            constant.MongoDb.user.findOne({ _id: Data.ReqUserId }, function (err, res) {
                                                if (!err && res != null) {
                                                    var payload = {
                                                        eventName: "BlockFriend",
                                                        userId: Data.id,
                                                        msg: Data.name + " is blocked you.",
                                                    }
                                                    let message = new constant.gcm.Message({
                                                        data: { payload },
                                                    })
                                                    constant.MongoDb.package.findOne({ _id: request.headers.app_secret }, function (err, result) {
                                                        if (result != null) {
                                                            constant.gcm.Sender(result.gcm_key).sendNoRetry(message, { registrationTokens: [res.payload.token] }, function (err, res) {
                                                                response.end(ConstantMethod.sucess(res))
                                                            })
                                                        } else {
                                                            constant.sender.sendNoRetry(message, { registrationTokens: [res.payload.token] }, function (err, response) {})
                                                        }
                                                    })
                                                }
                                            })

                                            constant.ensureDirectoryExistence([constant.Proj_dir + "/Resource/ChatFile/" + Data.ReqUserId + "_" + Data.id, constant.Proj_dir + "/Resource/ChatFile/" + Data.id + "_" + Data.ReqUserId], function (path) {
                                                if (path != null) {
                                                    try {
                                                        constant.fs.unlinkSync(path + "/chat.json")
                                                        constant.fs.rmdirSync(path)
                                                    } catch (error) {
                                                        // your catch block code goes here
                                                    }
                                                }
                                            })
                                            response.end(ConstantMethod.sucess(JSON.stringify(Data)))
                                        } else {
                                            response.status(500).send(ConstantMethod.Error(err))
                                        }
                                    })
                                }

                                break
                            case "DeleteFriend":
                                {
                                    delete Data["eventName"]

                                    let batch = constant.MongoDb.friend.initializeUnorderedBulkOp({ useLegacyOps: true })

                                    batch.find({ _id: Data.id }).updateOne({
                                        $pull: { "payload.accepted": Data.ReqUserId },
                                    })
                                    batch.find({ _id: Data.ReqUserId }).updateOne({
                                        $pull: { "payload.accepted": Data.id },
                                    })

                                    batch.execute(function (err, result) {
                                        if (!err) {
                                            constant.MongoDb.user
                                                .aggregate([
                                                    { $match: { _id: Data.ReqUserId } },
                                                    {
                                                        $lookup: {
                                                            from: "liveuser",
                                                            localField: "_id",
                                                            foreignField: "_id",
                                                            as: "user",
                                                        },
                                                    },

                                                    { $unwind: { path: "$user", preserveNullAndEmptyArrays: true } },
                                                    { $replaceRoot: { newRoot: { $mergeObjects: ["$payload", "$user.payload"] } } },
                                                ])
                                                .toArray(function (err, res) {
                                                    if (!err && res != null && res.length > 0 && res[0].hasOwnProperty("SocketId")) {
                                                        constant.io.to(res[0].SocketId).emit("VideoClient", {
                                                            eventName: "DeleteFriend",
                                                            userId: Data.id,
                                                        })
                                                    } else if (res != null && res.length > 0) {
                                                        var payload = {
                                                            eventName: "DeleteFriend",
                                                            userId: Data.id,
                                                        }
                                                        let message = new constant.gcm.Message({
                                                            data: { payload },
                                                        })
                                                        constant.MongoDb.package.findOne({ _id: request.headers.app_secret }, function (err, result) {
                                                            if (result != null) {
                                                                constant.gcm.Sender(result.gcm_key).sendNoRetry(message, { registrationTokens: [res[0].token] }, function (err, res) {
                                                                    response.end(ConstantMethod.sucess(res))
                                                                })
                                                            } else {
                                                                constant.sender.sendNoRetry(message, { registrationTokens: [res[0].token] }, function (err, response) {})
                                                            }
                                                        })
                                                    }
                                                })

                                            constant.ensureDirectoryExistence([constant.Proj_dir + "/Resource/ChatFile/" + Data.ReqUserId + "_" + Data.id, constant.Proj_dir + "/Resource/ChatFile/" + Data.id + "_" + Data.ReqUserId], function (path) {
                                                if (path != null) {
                                                    try {
                                                        constant.fs.unlinkSync(path + "/chat.json")
                                                        constant.fs.rmdirSync(path)
                                                    } catch (error) {
                                                        // your catch block code goes here
                                                    }
                                                }
                                            })
                                            response.end(ConstantMethod.sucess(JSON.stringify(Data)))
                                        } else {
                                            response.status(500).send(ConstantMethod.Error(err))
                                        }
                                    })
                                }
                                break
                            case "IsChatExist":
                                constant.MongoDb.friend.findOne(
                                    {
                                        _id: Data.userId,
                                        "payload.accepted": Data.OtherUserId,
                                    },
                                    function (err, res) {
                                        if (!err && res != null) {
                                            //restore chat if user dont have any message in local history.

                                            constant.ensureDirectoryExistence([constant.Proj_dir + "/Resource/ChatFile/" + Data.userId + "_" + Data.OtherUserId, constant.Proj_dir + "/Resource/ChatFile/" + Data.OtherUserId + "_" + Data.userId], function (path) {
                                                if (path == null) {
                                                    response.status(500).send(ConstantMethod.Error("File not existed."))
                                                    return
                                                }

                                                let command = constant.Proj_dir + "/shell_script/read.sh  -fi=" + path + "/chat.json"

                                                constant.cmd.get(command, function (err, resdata, stderr) {
                                                    if (!err) {
                                                        response.end(ConstantMethod.sucess(resdata))
                                                        // console.log("output json-->",JSON.stringify(resdata))
                                                    }
                                                })
                                            })
                                        } else response.status(500).send(ConstantMethod.Error("User not existed."))
                                    }
                                )

                                break

                            case "current_timeStamp":
                                let currentTime = new Date().getTime()
                                response.end(ConstantMethod.sucess(JSON.stringify(currentTime)))
                                break

                            case "coin_plus":
                                constant.MongoDb.user.createIndex({ "payload.userId": 1 }, { background: true })
                                constant.MongoDb.user
                                    .findOneAndUpdate(
                                        {
                                            "payload.userId": Data.userId,
                                            "payload.package_name": Data.packageName,
                                        },
                                        {
                                            $set: {
                                                devicedId: Data.deviceId,
                                            },
                                            $inc: {
                                                "payload.Coin": Data.coin,
                                            },
                                        },
                                        { new: true }
                                    )
                                    .then((resdata) => {
                                        constant.MongoDb.user.findOne({ "payload.userId": Data.userId }, function (err, res) {
                                            if (!err && res != null) {
                                                constant.MongoDb.coin_history.insertOne(
                                                    {
                                                        package_name: Data.packageName,
                                                        rewardad_type: Data.rewardadType,
                                                        user_id: Data.userId,
                                                        added_coin: Data.coin,
                                                        timestamp: new Date().getTime(),
                                                    },
                                                    function (err) {
                                                        console.log("err", err)
                                                        if (!err) {
                                                            response.end(ConstantMethod.sucess('"coin History sucessfully"'))
                                                        } else {
                                                            response.status(500).send(ConstantMethod.Invalid())
                                                        }
                                                    }
                                                )

                                                // res.timestamp=new Date().getTime()

                                                const resp = {
                                                    ...res,
                                                    timestamp: new Date().getTime(),
                                                }

                                                response.end(ConstantMethod.sucess(JSON.stringify(resp)))
                                            } else {
                                                response.status(500).send(ConstantMethod.Error(err))
                                            }
                                        })
                                    })
                                    .catch((error) => {
                                        console.error("Error updating coin value:", error)
                                        // Handle the error accordingly
                                        response.status(500).send(ConstantMethod.Error("Internal Server Error"))
                                    })

                                break

                            case "coin_minus":
                                constant.MongoDb.user.createIndex({ "payload.userId": 1 }, { background: true })
                                constant.MongoDb.user
                                    .findOneAndUpdate(
                                        {
                                            "payload.userId": Data.userId,
                                            "payload.package_name": Data.packageName,
                                            "payload.Coin": { $gte: Data.coin },
                                        },
                                        {
                                            $set: {
                                                devicedId: Data.deviceId,
                                            },
                                            $inc: {
                                                "payload.Coin": -Data.coin,
                                            },
                                        },
                                        { new: true }
                                    )
                                    .then((resdata) => {
                                        // console.log("resData", JSON.stringify(resdata))
                                        constant.MongoDb.user.findOne({ "payload.userId": Data.userId, "payload.package_name": Data.packageName }, function (err, res) {
                                            if (!err && res != null) {
                                                response.end(ConstantMethod.sucess(JSON.stringify(res)))
                                            } else {
                                                response.status(500).send(ConstantMethod.Error(err))
                                            }
                                        })
                                    })
                                    .catch((error) => {
                                        console.error("Error updating coin value:", error)
                                        // Handle the error accordingly
                                        response.status(500).send(ConstantMethod.Error("Internal Server Error"))
                                    })

                                break

                            case "get_rewardad_history":
                                constant.MongoDb.user.createIndex({ "payload.userId": 1 }, { background: true })

                                let countCoin = 0
                                constant.MongoDb.user.findOne({ "payload.userId": Data.userId, "payload.package_name": Data.packageName }, function (err, resp) {
                                    if (err) {
                                        console.error("Error finding records:", err)
                                        response.end(ConstantMethod.Error(err))
                                    } else {
                                        countCoin = resp.payload.Coin

                                        const oneHourAgo = new Date().getTime() - +Data.per_hour * 3600000 // Calculate the timestamp 1 hour ago

                                        constant.MongoDb.coin_history.find({ user_id: Data.userId, timestamp: { $gte: oneHourAgo }, package_name: Data.packageName, rewardad_type: { $nin: ["free", "welcome"] } }).toArray(function (err, res) {
                                            if (err) {
                                                console.error("Error finding records:", err)
                                                response.end(ConstantMethod.Error(err))
                                            } else {
                                                let maxTimestamp

                                                maxTimestamp = res.reduce((max, entry) => Math.max(max, entry.timestamp), -1)

                                                if (maxTimestamp == -1) {
                                                    let maxTotalTimestamp = -1
                                                    constant.MongoDb.coin_history.find({ user_id: Data.userId, package_name: Data.packageName, rewardad_type: { $nin: ["free", "welcome"] } }).toArray(function (err, resp) {
                                                        if (err) {
                                                            response.end(ConstantMethod.Error(err))
                                                        } else {
                                                            resp.forEach((entry) => {
                                                                maxTotalTimestamp = Math.max(maxTotalTimestamp, entry.timestamp)
                                                            })

                                                            const respdata = {
                                                                count: res.length,
                                                                timestamp: maxTotalTimestamp == -1 ? 0 : maxTotalTimestamp,
                                                                totalCoin: countCoin,
                                                                currentTime: new Date().getTime(),
                                                            }
                                                            return response.end(ConstantMethod.sucess(JSON.stringify(respdata)))
                                                        }
                                                    })
                                                } else {
                                                    const respdata = {
                                                        count: res.length,
                                                        timestamp: maxTimestamp == -1 ? 0 : maxTimestamp,
                                                        totalCoin: countCoin,
                                                        currentTime: new Date().getTime(),
                                                    }
                                                    return response.end(ConstantMethod.sucess(JSON.stringify(respdata)))
                                                }
                                            }
                                        })
                                    }
                                })
                                break

                            case "get_rewardad_history_free":
                                constant.MongoDb.user.createIndex({ "payload.userId": 1 }, { background: true })
                                let countCoins = 0
                                constant.MongoDb.user.findOne({ "payload.userId": Data.userId, "payload.package_name": Data.packageName }, function (err, resp) {
                                    if (err) {
                                        console.error("Error finding records:", err)
                                        response.end(ConstantMethod.Error(err))
                                    } else {
                                        countCoins = resp.payload.Coin

                                        const oneHourAgo = new Date().getTime() - 86400000 // Calculate the timestamp 1 hour ago

                                        constant.MongoDb.coin_history.find({ user_id: Data.userId, timestamp: { $gte: oneHourAgo }, package_name: Data.packageName, rewardad_type: "free" }).toArray(function (err, res) {
                                            if (err) {
                                                console.error("Error finding records:", err)
                                                response.end(ConstantMethod.Error(err))
                                            } else {
                                                let maxTimestamp

                                                maxTimestamp = res.reduce((max, entry) => Math.max(max, entry.timestamp), -1)

                                                if (maxTimestamp == -1) {
                                                    let maxTotalTimestamp = -1
                                                    constant.MongoDb.coin_history.find({ user_id: Data.userId, package_name: Data.packageName, rewardad_type: "free" }).toArray(function (err, resp) {
                                                        if (err) {
                                                            response.end(ConstantMethod.Error(err))
                                                        } else {
                                                            resp.forEach((entry) => {
                                                                maxTotalTimestamp = Math.max(maxTotalTimestamp, entry.timestamp)
                                                            })
                                                            const respdata = {
                                                                freeCoinStatus: res.length == 0 ? true : false,
                                                                timestamp: maxTotalTimestamp == -1 ? 0 : maxTotalTimestamp,
                                                                totalCoin: countCoins,
                                                                currentTime: new Date().getTime(),
                                                            }
                                                            return response.end(ConstantMethod.sucess(JSON.stringify(respdata)))
                                                        }
                                                    })
                                                } else {
                                                    const respdata = {
                                                        freeCoinStatus: res.length == 0 ? true : false,
                                                        timestamp: maxTimestamp == -1 ? 0 : maxTimestamp,
                                                        totalCoin: countCoins,
                                                        currentTime: new Date().getTime(),
                                                    }
                                                    return response.end(ConstantMethod.sucess(JSON.stringify(respdata)))
                                                }
                                            }
                                        })
                                    }
                                })
                                break

                            case "test":
                                _this.call(constant, response)
                                break
                            default:
                                response.status(500).send(ConstantMethod.Invalid())
                                break
                        }
                    } else {
                        response.end(ConstantMethod.Error("Header is missing!!"))
                        // console.log("Header is worng-->",Data);
                    }
                })
            }
        })
    },
    call: function (constant, response) {
        //  console.log("before")
        constant.MongoDb.user.find({ _id: 45 }, function (err, res) {
            if (!err) {
                response.end(ConstantMethod.sucess("User updated"))
            } else {
                response.end(ConstantMethod.Error(err))
            }
            //console.log("result1")
        })
        // console.log("end")
    },
    MultipleBatch: function (constant, Data, callback) {
        delete Data["eventName"]
        constant.MongoDb.friend.find({ _id: { $in: [Data.id, Data.ReqUserId] } }).toArray(function (err, res) {
            if (!err && res != null) {
                let batch = constant.MongoDb.friend.initializeUnorderedBulkOp({ useLegacyOps: true })
                if (res != null && res.length > 1) {
                    constant.MongoDb.friend.findOne(
                        {
                            _id: Data.id,
                            "payload.pending": { $in: [Data.ReqUserId] },
                        },
                        function (err, res) {
                            if (res === null) {
                                batch.find({ _id: Data.id }).updateOne({ $addToSet: { "payload.sent": Data.ReqUserId } })
                                batch.find({ _id: Data.ReqUserId }).updateOne({ $addToSet: { "payload.pending": Data.id } })
                                callback(batch)
                            } else {
                                callback(null)
                                // response.status(500).send(ConstantMethod.Error(err));
                            }
                        }
                    )
                } else if (res != null && res.length > 0) {
                    if (res[0]._id === Data.id) {
                        constant.MongoDb.friend.findOne(
                            {
                                _id: Data.id,
                                "payload.pending": { $in: [Data.ReqUserId] },
                            },
                            function (err, res) {
                                if (res == null) {
                                    batch.find({ _id: Data.id }).updateOne({ $addToSet: { "payload.sent": Data.ReqUserId } })
                                    batch.insert({
                                        _id: Data.ReqUserId,
                                        payload: {
                                            sent: [],
                                            pending: [Data.id],
                                            accepted: [],
                                            rejected: [],
                                            rejectedByOther: [],
                                        },
                                    })
                                    callback(batch)
                                } else {
                                    // response.status(500).send(ConstantMethod.Error(err));
                                    callback(null)
                                }
                            }
                        )
                    } else {
                        constant.MongoDb.friend.findOne(
                            {
                                _id: Data.ReqUserId,
                                "payload.sent": { $in: [Data.id] },
                            },
                            function (err, res) {
                                if (res == null) {
                                    batch.find({ _id: Data.ReqUserId }).updateOne({ $addToSet: { "payload.pending": Data.id } })
                                    batch.insert({
                                        _id: Data.id,
                                        payload: {
                                            sent: [Data.ReqUserId],
                                            pending: [],
                                            accepted: [],
                                            rejected: [],
                                            rejectedByOther: [],
                                        },
                                    })
                                    callback(batch)
                                } else {
                                    // response.status(500).send(ConstantMethod.Error(err));
                                    callback(null)
                                }
                            }
                        )
                    }
                } else {
                    batch.insert({
                        _id: Data.id,
                        payload: {
                            sent: [Data.ReqUserId],
                            pending: [],
                            accepted: [],
                            rejected: [],
                            rejectedByOther: [],
                        },
                    })
                    batch.insert({
                        _id: Data.ReqUserId,
                        payload: {
                            sent: [],
                            pending: [Data.id],
                            accepted: [],
                            rejected: [],
                            rejectedByOther: [],
                        },
                    })
                    callback(batch)
                }
            } else {
                // response.status(500).send(ConstantMethod.Error(err));
                callback(null)
            }
        })
    },
})
