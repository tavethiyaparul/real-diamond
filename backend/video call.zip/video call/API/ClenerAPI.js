"use strict";
let ConstantMethod = require('../Utils/ConstantMethod');


var _this = module.exports = {


    Clean: function (constant) {

        constant.app.post('/clean', constant.FileUpload.single('image'), function (request, response) {
            let Data = request.body;
            if (Data.length > 1e6) {
                // FLOOD ATTACK OR FAULTY CLIENT, NUKE REQUEST
                response.end(ConstantMethod.Error("FLOOD ATTACK OR FAULTY CLIENT, NUKE REQUEST."));
                request.connection.destroy();
            } else {
                ConstantMethod.CheckHeader(request, constant, function (isValideHeader) {
                    if (isValideHeader) {
                        switch (Data.eventName) {
                            case "DeleteUser":
                                constant.MongoDb.user.findOne(
                                    {_id: Data.userId}
                                    , function (err, res) {
                                        if (!err && res != null) {
                                            let _arr_id = [];
                                            let arr_res = [res];
                                            //console.log(arr_res)
                                            _this.CallBack(constant, arr_res.length - 1, arr_res, _arr_id, function (arr) {
                                                response.end(ConstantMethod.sucess(JSON.stringify({
                                                    _id: arr
                                                })));
                                            });
                                        }
                                    });


                                break;
                            case "User":
                                let d = new Date();
                                d.setDate(d.getDate() - 10);

                                constant.MongoDb.user.aggregate([


                                    {
                                        $match: {
                                            // $and: [
                                            //     {$or: [{"payload.Coin": {$exists: false}}, {"payload.Coin": {$lt: 1}}]},
                                            //     {
                                            $or: [
                                                {"payload.Lastlogin": {$exists: false}},
                                                {"payload.Lastlogin": {$lt: d}}

                                            ]
                                            //     }
                                            // ]
                                        }

                                    },


                                    {
                                        $project: {
                                            "_id": 1,

                                            "payload": 1
                                        }
                                    }
                                ]).toArray(function (err, res) {
                                    if (!err && res != null) {
                                        let _arr_id = [];
                                        _this.CallBack(constant, res.length - 1, res, _arr_id, function (arr) {
                                            response.end(ConstantMethod.sucess(JSON.stringify({
                                                _id: arr
                                            })));
                                        });
                                    } else
                                        response.end(ConstantMethod.Error("No record found!!"));
                                });


                                break;

                            default:
                                response.status(500).send(ConstantMethod.Invalid());
                                break;
                        }
                    } else {
                        response.end(ConstantMethod.Error("Header is missing!!"));
                    }
                })
            }
        });
    },

    CallBack: function (constant, index, result, _arr_id, callback) {
        if (index > -1) {
            let id = result[index]._id;
            _arr_id.push(id);
            /*remove history*/
            let batch = constant.MongoDb.history.initializeUnorderedBulkOp({useLegacyOps: true});
            //batch.find({_id: id}).remove();
            batch.find({}).update({$pull: {"payload.caller": {"id": {$in: [id]}}}});
            batch.execute(function (err, res) {

                batch = constant.MongoDb.friend.initializeUnorderedBulkOp({useLegacyOps: true});
                batch.find({_id: id}).remove();
                batch.find({}).update({
                    $pull: {
                        "payload.sent": {$in: [id]},
                        "payload.pending": {$in: [id]},
                        "payload.accepted": {$in: [id]},
                        "payload.rejected": {$in: [id]},
                        "payload.rejectedByOther": {$in: [id]}
                    }
                });
                batch.execute(function (err, res) {
                    batch = constant.MongoDb.user.initializeUnorderedBulkOp({useLegacyOps: true});
                    //batch.find({_id: id, $or: [{"payload.Coin": {$eq: 0}}, {"payload.Coin": {$lt: 0}}]}).remove();
					batch.find({_id: id}).update( { $set: { "payload.Profile": ""} } );
                    batch.execute(function (err, res) {
                        let command = "find " + constant.Proj_dir + "/Resource/ChatFile  -type d -name '*" + id + "*' -exec rm -rv {} +";

                        constant.cmd.get(command,
                            function (err, resdata, stderr) {
                                // console.log("result-->",resdata)
                                // console.log("error-->",err)
                                //console.log("profile", JSON.stringify(result[index].payload))
                                if (result[index].hasOwnProperty("payload") && result[index].payload.hasOwnProperty("Profile") && result[index].payload.Profile !== null && !result[index].payload.Profile.includes("http")) {
                                    // profile.push(res[i].payload.Profile);
                                    constant.ensureDirectoryExistence([constant.Proj_dir + "/Resource/ProfilePic/" + result[index].payload.Profile], function (path) {
                                        if (path != null) {
                                            try{
                                                constant.fs.unlinkSync(path);
                                            }
                                            catch (error) { 
                                             // your catch block code goes here
                                            }

                                             //console.log("deleted-->", id, "Remaining-->", index)
                                            _this.CallBack(constant, index - 1, result, _arr_id, callback);
                                        } else {
                                            //console.log("deleted-->", id, "Remaining-->", index)
                                            _this.CallBack(constant, index - 1, result, _arr_id, callback);
                                        }
                                    });
                                } else {
                                    //console.log("deleted-->", id, "Remaining-->", index)
                                    _this.CallBack(constant, index - 1, result, _arr_id, callback);
                                }


                            });
                    });

                });


            });


        } else {
            callback(_arr_id);
        }
    }
};